"""Duyuru görselleri PostgreSQL'de, yalnızca kendi sitesine açık saklanır."""
from io import BytesIO
from uuid import uuid4
from PIL import Image, ImageOps, UnidentifiedImageError
from flask import Blueprint, request, jsonify, Response
from .db import transaction, one_row
from .security import admin_required, site_member_required, audit
from .validation import ApiError
from .rate_limit import enforce_limit
from flask import g

bp=Blueprint('media',__name__,url_prefix='/api/announcement-images')


@bp.post('')
@admin_required
def upload():
    enforce_limit('announcement-upload',str(g.user['id']),30,3600)
    file=request.files.get('image')
    if not file:
        raise ApiError('Bir görsel seçin.')
    data=file.read(5*1024*1024+1)
    if len(data)>5*1024*1024:
        raise ApiError('Görsel en fazla 5 MB olabilir.',413)
    try:
        with Image.open(BytesIO(data),formats=('PNG','JPEG','WEBP')) as source:
            if source.width*source.height>16000000:
                raise ApiError('Görsel en fazla 16 milyon piksel olabilir.')
            source.load()
            image=ImageOps.exif_transpose(source).convert('RGB')
            image.thumbnail((1920,1920))
            out=BytesIO()
            # Yeniden kodlama yüklenen dosyanın metaveri ve ek içeriğini temizler.
            image.save(out,format='WEBP',quality=85)
            encoded=out.getvalue()
    except (UnidentifiedImageError,OSError,ValueError,Image.DecompressionBombError):
        raise ApiError('Geçerli bir JPEG, PNG veya WebP görseli yükleyin.')
    if len(encoded)>5*1024*1024:
        raise ApiError('Görsel çok büyük.',413)
    image_id=str(uuid4())
    with transaction() as cur:
        cur.execute("""DELETE FROM announcement_images i WHERE i.created_at<NOW()-INTERVAL '1 day'
            AND NOT EXISTS(SELECT 1 FROM announcements a WHERE a.image_id=i.id)""")
        cur.execute('INSERT INTO announcement_images(id,data) VALUES(%s,%s)',(image_id,encoded))
        audit(cur,'announcement.image_uploaded',detail={'image_id':image_id})
    return jsonify(id=image_id),201


@bp.get('/<uuid:image_id>')
@site_member_required
def image_file(image_id):
    row=one_row('SELECT data FROM announcement_images WHERE id=%s',(str(image_id),))
    if not row:
        raise ApiError('Görsel bulunamadı.',404)
    return Response(bytes(row['data']),mimetype='image/webp',headers={'Cache-Control':'private, no-store'})
