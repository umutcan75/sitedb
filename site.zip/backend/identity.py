"""Kimlik doğrulama sonucu oturum ve rol denetiminden ayrı tutulur."""
from dataclasses import dataclass
import secrets
import bcrypt


@dataclass(frozen=True)
class AuthenticatedIdentity:
    user_id: int
    methods: tuple[str, ...]


class PasswordAuthenticator:
    def __init__(self):
        self._rejection_hash = bcrypt.hashpw(secrets.token_bytes(32), bcrypt.gensalt())

    def authenticate(self, user, supplied):
        if not isinstance(supplied, str) or len(supplied.encode('utf-8')) > 72:
            return None
        stored = user.get('password_hash', '') if user else ''
        candidate = stored.encode() if stored.startswith(('$2a$', '$2b$', '$2y$')) else self._rejection_hash
        try:
            valid = bcrypt.checkpw(supplied.encode(), candidate)
        except ValueError:
            valid = False
        if not valid or not user or not user['active']:
            return None
        return AuthenticatedIdentity(user['id'], ('password',))


def hash_password(value):
    return bcrypt.hashpw(value.encode('utf-8'), bcrypt.gensalt(rounds=12)).decode()


password_authenticator = PasswordAuthenticator()
