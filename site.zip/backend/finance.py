from .dates import today
from uuid import UUID
from flask import Blueprint, g, jsonify, request
from .db import all_rows, one_row, transaction
from .security import admin_required, login_required, scope, apartment_access, audit
from .validation import ApiError, body, text, integer, money, day, choice

bp=Blueprint('finance',__name__,url_prefix='/api')


@bp.get('/charges')
@login_required
def charges():
    condition,params=scope()
    if request.args.get('apartment_id'):
        condition+=' AND a.id=%s'
        params.append(integer(request.args,'apartment_id'))
    if request.args.get('period'):
        condition+=' AND c.period=%s'
        params.append(day({'period':request.args['period']+'-01'},'period'))
    return jsonify(all_rows(f'''SELECT c.*,a.block,a.number,
        GREATEST(LEAST(c.amount,c.running-COALESCE(p.total,0)),0) AS outstanding
        FROM (SELECT *,sum(amount) OVER(PARTITION BY apartment_id ORDER BY due_date,period,id) running FROM charges) c
        JOIN apartments a ON a.id=c.apartment_id
        LEFT JOIN (SELECT apartment_id,sum(amount) total FROM payments WHERE voided_at IS NULL AND status='approved' GROUP BY apartment_id) p ON p.apartment_id=a.id
        WHERE {condition} ORDER BY c.period DESC,a.block,a.number''',params))


@bp.post('/charges/batch')
@admin_required
def batch_charges():
    data=body()
    period=day({'period':text(data,'period',7)+'-01'},'period')
    due,amount=day(data,'due_date'),money(data)
    if due<period:
        raise ApiError('Son ödeme tarihi aidat döneminden önce olamaz.')
    description=text(data,'description',250)
    with transaction() as cur:
        cur.execute('''INSERT INTO charges(apartment_id,period,due_date,amount,description,created_by)
                       SELECT id,%s,%s,%s,%s,%s FROM apartments WHERE active
                       ON CONFLICT(apartment_id,period) DO NOTHING RETURNING id''',
                    (period,due,amount,description,g.user['id']))
        count=len(cur.fetchall())
        audit(cur,'charges.batch',detail={'period':str(period),'count':count})
    return jsonify(message=f'{count} daire için aidat oluşturuldu. Mevcut dönem kayıtları korundu.',count=count),201


@bp.put('/charges/<int:row_id>')
@admin_required
def update_charge(row_id):
    data=body()
    amount,due,description=money(data),day(data,'due_date'),text(data,'description',250)
    with transaction() as cur:
        cur.execute('SELECT * FROM charges WHERE id=%s FOR UPDATE',(row_id,))
        before=cur.fetchone()
        if not before:
            raise ApiError('Aidat bulunamadı.',404)
        if due<before['period']:
            raise ApiError('Son ödeme tarihi dönemden önce olamaz.')
        cur.execute('UPDATE charges SET amount=%s,due_date=%s,description=%s WHERE id=%s',(amount,due,description,row_id))
        audit(cur,'charge.update',row_id,{'old_amount':str(before['amount']),'new_amount':str(amount)})
    return jsonify(message='Aidat güncellendi; daire bakiyesi yeniden hesaplandı.')


@bp.delete('/charges/<int:row_id>')
@admin_required
def delete_charge(row_id):
    with transaction() as cur:
        cur.execute('DELETE FROM charges WHERE id=%s RETURNING amount,apartment_id',(row_id,))
        before=cur.fetchone()
        if not before:
            raise ApiError('Aidat bulunamadı.',404)
        audit(cur,'charge.delete',row_id,{'amount':str(before['amount']),'apartment_id':before['apartment_id']})
    return jsonify(message='Aidat silindi. Mevcut ödemeler daire hesabında kaldı.')


@bp.get('/payments')
@login_required
def payments():
    condition,params=scope()
    if request.args.get('apartment_id'):
        condition+=' AND a.id=%s'
        params.append(integer(request.args,'apartment_id'))
    return jsonify(all_rows(f'''SELECT p.*,a.block,a.number FROM payments p JOIN apartments a ON a.id=p.apartment_id
                               WHERE {condition} ORDER BY p.paid_on DESC,p.id DESC''',params))


@bp.post('/payments')
@login_required
def create_payment():
    data=body()
    apartment_id=integer(data,'apartment_id')
    apartment_access(apartment_id)
    amount,paid_on,method,note=money(data),day(data,'paid_on'),choice(data,'method',('cash','transfer','card')),text(data,'note',500,False)
    if paid_on>today():
        raise ApiError('İleri tarihli tahsilat kaydedilemez.')
    try:
        key=str(UUID(str(data.get('idempotency_key'))))
    except (ValueError,TypeError):
        raise ApiError('Geçerli bir idempotency_key (UUID) gereklidir.')
    with transaction() as cur:
        cur.execute('''INSERT INTO payments(apartment_id,amount,paid_on,method,note,idempotency_key,created_by,received_by_name)
                       VALUES(%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(idempotency_key) DO NOTHING RETURNING *''',
                    (apartment_id,amount,paid_on,method,note,key,g.user['id'],g.user['full_name']))
        row=cur.fetchone()
        if not row:
            cur.execute('SELECT * FROM payments WHERE idempotency_key=%s',(key,))
            row=cur.fetchone()
            if not row:
                raise ApiError('Bu işlem anahtarı daha önce kullanılmış. Yeni bir işlem anahtarı ile deneyin.',409)
            if any((row['apartment_id']!=apartment_id,row['amount']!=amount,row['paid_on']!=paid_on,
                    row['method']!=method,row['note']!=note,row['created_by']!=g.user['id'])):
                raise ApiError('Bu işlem anahtarı farklı bir ödeme için kullanılmış.',409)
            return jsonify(row),200
        audit(cur,'payment.create',row['id'],{'amount':str(amount),'receipt':row['receipt_no']})
    return jsonify(row),201


@bp.post('/payments/<int:row_id>/review')
@admin_required
def review_payment(row_id):
    data=body()
    decision=choice(data,'decision',('approved','rejected'))
    note=text(data,'note',500,decision=='rejected')
    with transaction() as cur:
        cur.execute('SELECT * FROM payments WHERE id=%s FOR UPDATE',(row_id,))
        row=cur.fetchone()
        if not row:
            raise ApiError('Ödeme bulunamadı.',404)
        if row['status']!='pending' or row['voided_at']:
            raise ApiError('Bu ödeme daha önce değerlendirilmiş.',409)
        # Makbuz yalnızca kabul anında üretilir; eşzamanlı onay tek kez işlenir.
        cur.execute("""UPDATE payments SET status=%s,reviewed_by=%s,reviewed_at=NOW(),review_note=%s,
            receipt_no=CASE WHEN %s='approved' THEN 'M-' || lpad(nextval('sitedb.receipt_seq')::text,10,'0') ELSE NULL END,
            received_by_name=%s WHERE id=%s RETURNING *""",
            (decision,g.user['id'],note,decision,g.user['full_name'],row_id))
        result=cur.fetchone()
        audit(cur,'payment.review',row_id,{'decision':decision,'amount':str(row['amount'])})
    return jsonify(result)


@bp.post('/payments/<int:row_id>/void')
@admin_required
def void_payment(row_id):
    reason=text(body(),'reason',500)
    with transaction() as cur:
        cur.execute('''UPDATE payments SET voided_at=NOW(),void_reason=%s,voided_by=%s
                       WHERE id=%s AND voided_at IS NULL AND status='approved' RETURNING id''',(reason,g.user['id'],row_id))
        if not cur.fetchone():
            raise ApiError('Tahsilat bulunamadı veya zaten iptal edilmiş.',409)
        audit(cur,'payment.void',row_id,{'reason':reason})
    return jsonify(message='Tahsilat iptal edildi; daire ve kasa bakiyeleri güncellendi.')


@bp.get('/payments/<int:row_id>/receipt')
@login_required
def receipt(row_id):
    row=one_row('''SELECT p.*,a.block,a.number,COALESCE(NULLIF(p.received_by_name,''),u.full_name,'Yetkili kullanıcı') AS received_by
                   FROM payments p JOIN apartments a ON a.id=p.apartment_id LEFT JOIN users u ON u.id=p.created_by
                   WHERE p.id=%s''',(row_id,))
    if not row:
        raise ApiError('Makbuz bulunamadı.',404)
    apartment_access(row['apartment_id'])
    if row['status'] != 'approved':
        raise ApiError('Yönetici onayı olmadan makbuz oluşturulamaz.',409)
    return jsonify(row)


@bp.get('/apartments/<int:row_id>/statement')
@login_required
def statement(row_id):
    apartment_access(row_id)
    rows=all_rows('''SELECT * FROM (
        SELECT id,period AS date,'charge' AS type,description,amount AS debit,0::numeric AS credit,NULL::text AS receipt_no
        FROM charges WHERE apartment_id=%s
        UNION ALL SELECT id,paid_on,'payment',COALESCE(NULLIF(note,''),'Aidat tahsilatı'),0,amount,receipt_no
        FROM payments WHERE apartment_id=%s AND voided_at IS NULL AND status='approved') movements ORDER BY date,type,id''',(row_id,row_id))
    from decimal import Decimal
    balance=Decimal('0')
    for row in rows:
        balance+=row['debit']-row['credit']
        row['balance']=balance
    return jsonify(apartment=one_row('SELECT * FROM apartment_balances WHERE id=%s',(row_id,)),rows=rows,balance=balance)


@bp.get('/categories')
@admin_required
def categories():
    return jsonify(all_rows('SELECT * FROM categories ORDER BY kind,name'))


@bp.post('/categories')
@admin_required
def create_category():
    data=body()
    name,kind=text(data,'name',100),choice(data,'kind',('income','expense'))
    with transaction() as cur:
        cur.execute('INSERT INTO categories(name,kind) VALUES(%s,%s) RETURNING *',(name,kind))
        row=cur.fetchone()
        audit(cur,'category.create',row['id'])
    return jsonify(row),201


@bp.put('/categories/<int:row_id>')
@admin_required
def update_category(row_id):
    # Kullanılmış kategorinin türü değiştirilmez; kasa hesabı geçmişe dönük yön değiştirmesin.
    name=text(body(),'name',100)
    with transaction() as cur:
        cur.execute('UPDATE categories SET name=%s WHERE id=%s RETURNING *',(name,row_id))
        row=cur.fetchone()
        if not row:
            raise ApiError('Kategori bulunamadı.',404)
        audit(cur,'category.update',row_id)
    return jsonify(row)


@bp.delete('/categories/<int:row_id>')
@admin_required
def delete_category(row_id):
    with transaction() as cur:
        cur.execute('DELETE FROM categories WHERE id=%s RETURNING id',(row_id,))
        if not cur.fetchone():
            raise ApiError('Kategori bulunamadı.',404)
        audit(cur,'category.delete',row_id)
    return jsonify(message='Kategori silindi.')


@bp.get('/ledger')
@admin_required
def ledger():
    clauses,params=[],[]
    for key,op in [('start','>='),('end','<=')]:
        if request.args.get(key):
            clauses.append(f'l.entry_date {op} %s')
            params.append(day(request.args,key))
    condition=' AND '.join(clauses) or 'TRUE'
    return jsonify(all_rows(f'''SELECT l.*,c.name AS category,c.kind FROM ledger_entries l
        JOIN categories c ON c.id=l.category_id WHERE {condition} ORDER BY l.entry_date DESC,l.id DESC''',params))


def ledger_values(data,cur):
    on=day(data,'entry_date')
    if on>today():
        raise ApiError('İleri tarihli kasa hareketi kaydedilemez.')
    description,amount=text(data,'description',500),money(data)
    kind=choice(data,'kind',('income','expense')) if data.get('kind') else None
    if data.get('category_id'):
        category_id=integer(data,'category_id')
        cur.execute('SELECT kind FROM categories WHERE id=%s',(category_id,))
        category=cur.fetchone()
        if not category:
            raise ApiError('Kategori bulunamadı.',404)
        if kind and category['kind']!=kind:
            raise ApiError('Seçilen kategori gelir/gider türüyle uyuşmuyor.')
    else:
        kind=choice(data,'kind',('income','expense'))
        name=text(data,'category_name',100)
        cur.execute("INSERT INTO categories(name,kind) VALUES(%s,%s) ON CONFLICT(site_id,name,kind) DO UPDATE SET name=EXCLUDED.name RETURNING id",(name,kind))
        category_id=cur.fetchone()['id']
    return category_id,description,on,amount


@bp.post('/ledger')
@admin_required
def create_ledger():
    data=body()
    with transaction() as cur:
        values=ledger_values(data,cur)
        cur.execute('''INSERT INTO ledger_entries(category_id,description,entry_date,amount,created_by)
                       VALUES(%s,%s,%s,%s,%s) RETURNING *''',values+(g.user['id'],))
        row=cur.fetchone()
        audit(cur,'ledger.create',row['id'],{'amount':str(row['amount'])})
    return jsonify(row),201


@bp.put('/ledger/<int:row_id>')
@admin_required
def update_ledger(row_id):
    data=body()
    with transaction() as cur:
        cur.execute('SELECT * FROM ledger_entries WHERE id=%s FOR UPDATE',(row_id,))
        before=cur.fetchone()
        if not before:
            raise ApiError('Kasa hareketi bulunamadı.',404)
        values=ledger_values(data,cur)
        cur.execute('''UPDATE ledger_entries SET category_id=%s,description=%s,entry_date=%s,amount=%s
                       WHERE id=%s RETURNING *''',values+(row_id,))
        row=cur.fetchone()
        audit(cur,'ledger.update',row_id,{'old_amount':str(before['amount']),'new_amount':str(row['amount'])})
    return jsonify(row)


@bp.delete('/ledger/<int:row_id>')
@admin_required
def delete_ledger(row_id):
    with transaction() as cur:
        cur.execute('DELETE FROM ledger_entries WHERE id=%s RETURNING amount,description',(row_id,))
        row=cur.fetchone()
        if not row:
            raise ApiError('Kasa hareketi bulunamadı.',404)
        audit(cur,'ledger.delete',row_id,{'amount':str(row['amount']),'description':row['description']})
    return jsonify(message='Kasa hareketi silindi.')
