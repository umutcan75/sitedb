"""İşlem dışında commit edilen, PostgreSQL üzerinde kalıcı istek sınırı."""
import hashlib
import hmac
from flask import current_app, request
from .db import transaction
from .validation import ApiError


def rate_key(bucket, identity):
    return hmac.new(current_app.secret_key.encode(), f'{bucket}:{identity}'.encode(), hashlib.sha256).hexdigest()


def enforce_limit(bucket, identity, maximum, seconds):
    key = rate_key(bucket, identity)
    with transaction() as cur:
        cur.execute('DELETE FROM rate_limits WHERE expires_at < NOW()')
        cur.execute('''INSERT INTO rate_limits(key,count,expires_at)
            VALUES(%s,1,NOW()+%s*INTERVAL '1 second')
            ON CONFLICT(key) DO UPDATE SET count=rate_limits.count+1 RETURNING count''', (key, seconds))
        count = cur.fetchone()['count']
    if count > maximum:
        raise ApiError('Çok fazla deneme yapıldı. Lütfen daha sonra tekrar deneyin.', 429)


def enforce_ip(bucket, maximum, seconds):
    enforce_limit(bucket, request.remote_addr or 'unknown', maximum, seconds)


def clear_limit(bucket, identity):
    with transaction() as cur:
        cur.execute('DELETE FROM rate_limits WHERE key=%s', (rate_key(bucket, identity),))
