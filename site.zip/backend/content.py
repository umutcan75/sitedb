from uuid import UUID
from flask import Blueprint, g, jsonify, request
from .db import all_rows, transaction
from .security import admin_required, login_required, site_member_required, audit
from .validation import ApiError, body, text, boolean, choice, day

bp=Blueprint('content',__name__,url_prefix='/api')


@bp.get('/announcements')
@site_member_required
def announcements():
    return jsonify(all_rows('''SELECT a.*,COALESCE(u.full_name,'Site yönetimi') AS author FROM announcements a
                              LEFT JOIN users u ON u.id=a.created_by ORDER BY pinned DESC,created_at DESC'''))


def announcement_values(data,cur):
    image_id=data.get('image_id') or None
    if image_id:
        try:
            image_id=str(UUID(str(image_id)))
        except ValueError:
            raise ApiError('Geçersiz görsel kimliği.')
        cur.execute('SELECT id FROM announcement_images WHERE id=%s FOR KEY SHARE',(image_id,))
        if not cur.fetchone():
            raise ApiError('Görsel bulunamadı veya bu siteye ait değil.',404)
    return (text(data,'title',180),text(data,'body',10000),boolean(data,'pinned'),image_id,
            choice(data,'category',('general','maintenance','meeting','event','urgent')) if data.get('category') else 'general',
            text(data,'summary',280,False),text(data,'location',160,False),day(data,'event_date',True))


@bp.post('/announcements')
@admin_required
def create_announcement():
    data=body()
    with transaction() as cur:
        values=announcement_values(data,cur)
        cur.execute('INSERT INTO announcements(title,body,pinned,image_id,category,summary,location,event_date,created_by) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *',values+(g.user['id'],))
        row=cur.fetchone()
        audit(cur,'announcement.create',row['id'])
    return jsonify(row),201


@bp.put('/announcements/<int:row_id>')
@admin_required
def update_announcement(row_id):
    data=body()
    with transaction() as cur:
        values=announcement_values(data,cur)
        cur.execute('UPDATE announcements SET title=%s,body=%s,pinned=%s,image_id=%s,category=%s,summary=%s,location=%s,event_date=%s,updated_at=NOW() WHERE id=%s RETURNING *',values+(row_id,))
        row=cur.fetchone()
        if not row:
            raise ApiError('Duyuru bulunamadı.',404)
        audit(cur,'announcement.update',row_id)
    return jsonify(row)


@bp.delete('/announcements/<int:row_id>')
@admin_required
def delete_announcement(row_id):
    with transaction() as cur:
        cur.execute('DELETE FROM announcements WHERE id=%s RETURNING id',(row_id,))
        if not cur.fetchone():
            raise ApiError('Duyuru bulunamadı.',404)
        audit(cur,'announcement.delete',row_id)
    return jsonify(message='Duyuru silindi.')


@bp.get('/tickets')
@login_required
def tickets():
    condition='TRUE' if g.user['role']=='admin' else 't.user_id=%s'
    params=[] if g.user['role']=='admin' else [g.user['id']]
    if request.args.get('status'):
        condition+=' AND t.status=%s'
        params.append(choice(request.args,'status',('open','progress','closed')))
    return jsonify(all_rows(f'''SELECT t.*,u.full_name,a.block,a.number FROM tickets t
            JOIN users u ON u.id=t.user_id LEFT JOIN apartments a ON a.id=t.apartment_id
            WHERE {condition} ORDER BY t.created_at DESC''',params))


@bp.post('/tickets')
@login_required
def create_ticket():
    data=body()
    values=(g.user['id'],g.user['apartment_id'],text(data,'title',180),text(data,'description',10000),
            choice(data,'priority',('low','normal','high','urgent')))
    with transaction() as cur:
        cur.execute('INSERT INTO tickets(user_id,apartment_id,title,description,priority) VALUES(%s,%s,%s,%s,%s) RETURNING *',values)
        row=cur.fetchone()
        audit(cur,'ticket.create',row['id'])
    return jsonify(row),201


@bp.put('/tickets/<int:row_id>')
@admin_required
def update_ticket(row_id):
    data=body()
    values=(choice(data,'status',('open','progress','closed')),text(data,'response',10000,False),row_id)
    with transaction() as cur:
        cur.execute('UPDATE tickets SET status=%s,response=%s,updated_at=NOW() WHERE id=%s RETURNING *',values)
        row=cur.fetchone()
        if not row:
            raise ApiError('Talep bulunamadı.',404)
        audit(cur,'ticket.update',row_id,{'status':row['status']})
    return jsonify(row)
