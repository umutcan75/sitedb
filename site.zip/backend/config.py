"""Tüm bağlantı bilgileri config.ini dosyasından okunur."""
import configparser
import os
import re
import ipaddress
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_config(path=None):
    file = Path(path or os.environ.get('SITEDB_CONFIG', ROOT / 'config.ini'))
    config = configparser.ConfigParser(interpolation=None)
    if not config.read(file, encoding='utf-8-sig'):
        raise RuntimeError(f'Yapılandırma bulunamadı: {file}. Veritabanı bağlantı ayarlarını config.ini dosyasına ekleyin.')
    for key in ('path', 'host', 'port', 'dbname', 'user', 'password'):
        if not config.has_option('DATABASE', key):
            raise RuntimeError(f'config.ini [DATABASE] bölümünde {key} eksik.')
    return config


def production_settings(config):
    """Canlı ortamda eksik güvenlik ayarlarıyla başlatmayı reddeder."""
    production = config.get('APP', 'environment', fallback='local') == 'production'
    hosts = [h.strip() for h in config.get('APP', 'trusted_hosts', fallback='').split(',') if h.strip()]
    if production:
        if not config.getboolean('APP', 'cookie_secure', fallback=False):
            raise RuntimeError('Canlı ortamda cookie_secure = true olmalıdır.')
        if not hosts or any(not valid_domain(h) for h in hosts):
            raise RuntimeError('Canlı ortamda trusted_hosts geçerli alan adlarını içermelidir.')
        if config.get('APP', 'host', fallback='127.0.0.1') != '127.0.0.1':
            raise RuntimeError('Canlı servis yalnızca 127.0.0.1 üzerinde dinlemelidir.')
        if config.get('APP', 'trusted_proxy', fallback='') != '127.0.0.1':
            raise RuntimeError('Canlı ortamda yerel HTTPS proxy adresi 127.0.0.1 olmalıdır.')
        origins = config.get('APP', 'allowed_origins', fallback='').split(',')
        if any(o.strip() and o.strip() not in ['https://' + h for h in hosts] for o in origins):
            raise RuntimeError('CORS yalnızca HTTPS alan adlarına izin verebilir.')
    return production, hosts


def valid_domain(value):
    if len(value) > 253 or '.' not in value:
        return False
    try:
        ipaddress.ip_address(value)
        return False
    except ValueError:
        return all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', part) for part in value.split('.'))


def db_params(config, database=None):
    db = config['DATABASE']
    return dict(host=db['host'], port=db.getint('port'), dbname=database or db['dbname'],
                user=db['user'], password=db['password'], connect_timeout=5)


def secret_key(config):
    # Rastgele anahtar disk üzerinde tutulur; yeniden başlatmalarda oturumlar korunur.
    import secrets
    file = Path(config['DATABASE']['path']) / '.secret_key'
    file.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, 'w', encoding='ascii') as stream:
            stream.write(secrets.token_hex(48))
    except FileExistsError:
        pass
    value = file.read_text(encoding='ascii').strip()
    if len(value) < 48:
        raise RuntimeError('Oturum anahtarı eksik veya çok kısa.')
    return value
