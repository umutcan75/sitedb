"""Thread-safe bağlantı havuzu ve işlem sınırları."""
from contextlib import contextmanager
from threading import BoundedSemaphore
from psycopg2.extras import RealDictCursor
from psycopg2.pool import ThreadedConnectionPool
from flask import current_app, g, has_request_context
from .config import db_params


class Database:
    def __init__(self, config):
        maximum = config.getint('APP', 'pool_max', fallback=12)
        self.slots = BoundedSemaphore(maximum)
        self.pool = ThreadedConnectionPool(config.getint('APP', 'pool_min', fallback=1), maximum,
                                          **db_params(config), options='-c search_path=sitedb,public -c timezone=Europe/Istanbul')

    @contextmanager
    def transaction(self):
        if not self.slots.acquire(timeout=10):
            raise TimeoutError('Veritabanı yoğun. Lütfen tekrar deneyin.')
        conn = None
        try:
            conn = self.pool.getconn()
            with conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                    user = getattr(g, 'user', None) if has_request_context() else None
                    if user and user['role'] != 'super_admin':
                        # Her işlemde rol ve kapsam yenilenir; havuza site bilgisi sızmaz.
                        cursor.execute('SET LOCAL ROLE sitedb_runtime')
                        cursor.execute("SELECT set_config('sitedb.site_id',%s,TRUE),set_config('sitedb.user_id',%s,TRUE)",
                                       (str(user.get('site_id') or ''), str(user['id'])))
                    yield cursor
        finally:
            if conn is not None:
                self.pool.putconn(conn, close=bool(conn.closed))
            self.slots.release()

    def close(self):
        if not self.pool.closed:
            self.pool.closeall()

    def verify_service_role(self):
        try:
            with self.transaction() as cur:
                cur.execute('SELECT rolsuper,rolbypassrls,rolcreatedb,rolcreaterole,rolinherit FROM pg_roles WHERE rolname=current_user')
                role = cur.fetchone()
                if any(role.values()):
                    raise RuntimeError('Canlı bağlantı için NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOINHERIT servis hesabı gereklidir.')
                cur.execute("SELECT pg_has_role(current_user,'sitedb_runtime','MEMBER') AS member")
                if not cur.fetchone()['member']:
                    raise RuntimeError('Servis hesabına sitedb_runtime rolü atanmalıdır.')
        except Exception:
            self.close()
            raise


def transaction():
    return current_app.extensions['database'].transaction()


def all_rows(query, params=()):
    with transaction() as cur:
        cur.execute(query, params)
        return cur.fetchall()


def one_row(query, params=()):
    with transaction() as cur:
        cur.execute(query, params)
        return cur.fetchone()
