"""Üyelik onayı, yetki değişikliği ve hesap kapatma yalnızca yöneticidedir."""
from flask import Blueprint, jsonify, request, g
from .db import all_rows, transaction
from .security import admin_required, audit
from .validation import ApiError, body, choice, boolean, text, password
from .identity import hash_password

bp = Blueprint('accounts', __name__, url_prefix='/api/accounts')


@bp.get('')
@admin_required
def accounts():
    query = '%' + request.args.get('q', '').strip()[:100] + '%'
    return jsonify(all_rows('''SELECT u.id,u.full_name,u.email,u.role,u.active,u.membership_status,
        u.created_at,r.apartment_id,a.block,a.number FROM users u
        LEFT JOIN residents r ON r.user_id=u.id LEFT JOIN apartments a ON a.id=r.apartment_id
        WHERE u.role='resident' AND (u.email ILIKE %s OR u.full_name ILIKE %s)
        ORDER BY (u.membership_status='pending') DESC,u.created_at DESC''', (query, query)))


@bp.put('/<int:user_id>')
@admin_required
def update_account(user_id):
    data = body()
    role = choice(data, 'role', ('admin', 'resident'))
    if role != 'resident':
        raise ApiError('Yönetici yetkisini yalnızca süper admin verebilir.',403)
    status = choice(data, 'membership_status', ('pending', 'approved'))
    active = boolean(data, 'active', True)
    full_name = text(data, 'full_name', 120)
    with transaction() as cur:
        # Hesap değişiklikleri ve platform atamaları aynı kilidi paylaşır.
        cur.execute('SELECT pg_advisory_xact_lock(817220603)')
        cur.execute('SELECT * FROM users WHERE id=%s FOR UPDATE', (user_id,))
        before = cur.fetchone()
        if before and before['role'] != 'resident':
            raise ApiError('Yönetici hesabını yalnızca süper admin değiştirebilir.',403)
        if not before:
            raise ApiError('Kullanıcı bulunamadı.', 404)
        if role == 'resident' and active and status == 'approved':
            cur.execute('SELECT id FROM residents WHERE user_id=%s AND move_out IS NULL', (user_id,))
            if not cur.fetchone():
                raise ApiError('Onay vermeden önce Sakinler ekranında kullanıcıyı bir daireye bağlayın.')
        cur.execute('''UPDATE users SET full_name=%s,role=%s,active=%s,membership_status=%s,updated_at=NOW()
            WHERE id=%s''', (full_name, role, active, status, user_id))
        cur.execute('DELETE FROM sessions WHERE user_id=%s', (user_id,))
        audit(cur, 'account.updated', user_id, {
            'old_role': before['role'], 'role': role,
            'old_status': before['membership_status'], 'status': status, 'active': active})
    return jsonify(message='Hesap güncellendi. Kullanıcının açık oturumları kapatıldı.')


@bp.post('/<int:user_id>/password')
@admin_required
def reset_password(user_id):
    value = password(body())
    with transaction() as cur:
        cur.execute('''UPDATE users SET password_hash=%s,must_change_password=TRUE,updated_at=NOW()
            WHERE id=%s AND role='resident' RETURNING id''', (hash_password(value), user_id))
        if not cur.fetchone():
            raise ApiError('Kullanıcı bulunamadı.', 404)
        cur.execute('DELETE FROM sessions WHERE user_id=%s', (user_id,))
        audit(cur, 'account.password_reset', user_id)
    return jsonify(message='Geçici şifre kaydedildi. Kullanıcı ilk girişte şifresini değiştirmelidir.')
