import atexit
import logging
from datetime import date, datetime, timedelta
from decimal import Decimal
from flask import Flask, jsonify, send_from_directory, request
from flask.json.provider import DefaultJSONProvider
from flask_cors import CORS
import psycopg2
from werkzeug.exceptions import HTTPException
from .config import ROOT, load_config, secret_key, production_settings
from .db import Database
from .security import csrf_check, load_user
from .validation import ApiError


class JSONProvider(DefaultJSONProvider):
    @staticmethod
    def default(value):
        # Parasal değerler JSON içinde metindir; float yuvarlama hatası taşınmaz.
        if isinstance(value, Decimal):
            return str(value)
        if isinstance(value, (date, datetime)):
            return value.isoformat()
        return DefaultJSONProvider.default(value)


def create_app(config_path=None):
    config = load_config(config_path)
    production, hosts = production_settings(config)
    app = Flask(__name__, static_folder=None)
    app.json = JSONProvider(app)
    app.config.update(SECRET_KEY=secret_key(config), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_NAME='sitedb_session',
                      SESSION_COOKIE_SECURE=config.getboolean('APP', 'cookie_secure', fallback=False),
                      TRUSTED_HOSTS=hosts or None,
                      PERMANENT_SESSION_LIFETIME=timedelta(hours=8), MAX_CONTENT_LENGTH=6*1024*1024,
                      MAX_FORM_PARTS=30, MAX_FORM_MEMORY_SIZE=64*1024)
    app.extensions['database'] = Database(config)
    if production:
        app.extensions['database'].verify_service_role()
    atexit.register(app.extensions['database'].close)
    origins = [v.strip() for v in config.get('APP', 'allowed_origins', fallback='').split(',') if v.strip()]
    CORS(app, resources={r'/api/*': {'origins': origins}}, supports_credentials=True,
         allow_headers=['Content-Type','X-CSRF-Token'], methods=['GET','POST','PUT','DELETE','OPTIONS'])
    @app.before_request
    def require_https():
        if production and not request.is_secure:
            raise ApiError('Bu servis HTTPS bağlantısı gerektirir.', 400)

    app.before_request(csrf_check)
    app.before_request(load_user)
    from . import auth, apartments, finance, content, reports, accounts, platform, visitors, media
    for module in (auth, apartments, finance, content, reports, accounts, platform, visitors, media):
        app.register_blueprint(module.bp)

    @app.get('/')
    def index():
        return send_from_directory(ROOT / 'frontend', 'index.html')

    @app.get('/assets/<path:name>')
    def assets(name):
        return send_from_directory(ROOT / 'frontend', name)

    @app.get('/api/health')
    def health():
        from .db import one_row
        one_row('SELECT 1')
        return jsonify(status='ok')

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
        if production and request.is_secure:
            response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
        if response.mimetype == 'application/json':
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.errorhandler(ApiError)
    def api_error(error):
        return jsonify(error=error.message), error.status

    @app.errorhandler(psycopg2.errors.InsufficientPrivilege)
    def scope_error(error):
        return jsonify(error='Bu kayıt için site erişim yetkiniz yok.'), 403

    @app.errorhandler(psycopg2.IntegrityError)
    def integrity(error):
        messages = {'23505': 'Bu kayıt zaten mevcut. Daire, e-posta veya dönem bilgisini kontrol edin.',
                    '23503': 'Kayıt bulunamadı veya ilişkili kayıtlar nedeniyle silinemiyor.',
                    '23514': 'Girdi değerleri veritabanı kurallarına uymuyor.'}
        return jsonify(error=messages.get(error.pgcode, 'Kayıt bütünlüğü hatası. Bilgileri kontrol edin.')), 409

    @app.errorhandler(HTTPException)
    def http_error(error):
        return jsonify(error={404:'Adres bulunamadı.',405:'Bu HTTP metodu desteklenmiyor.',413:'İstek çok büyük.'}.get(error.code,'İstek işlenemedi.')), error.code

    @app.errorhandler(Exception)
    def unknown(error):
        logging.exception('İstek işlenirken hata oluştu')
        status = 503 if isinstance(error, (psycopg2.OperationalError, TimeoutError)) else 500
        return jsonify(error='Hizmete şu anda erişilemiyor. Lütfen tekrar deneyin.'), status
    return app
