"""API girdilerinde tip, uzunluk ve parasal hassasiyet kontrolü."""
import re
from datetime import date
from decimal import Decimal, InvalidOperation
from flask import request


class ApiError(Exception):
    def __init__(self, message, status=400):
        self.message, self.status = message, status


def body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ApiError('JSON nesnesi gönderilmelidir.')
    return data


def text(data, key, maximum=250, required=True):
    value = data.get(key, '')
    if not isinstance(value, str):
        raise ApiError(f'{key}: metin bekleniyor.')
    value = value.strip()
    if (required and not value) or len(value) > maximum:
        raise ApiError(f'{key}: ' + (f'1–{maximum} karakter girin.' if required else f'En fazla {maximum} karakter girin.'))
    return value


def integer(data, key, minimum=1, maximum=2147483647):
    value = data.get(key)
    if isinstance(value, bool) or not re.fullmatch(r'-?\d+', str(value)):
        raise ApiError(f'{key}: tam sayı girin.')
    result = int(value)
    if not minimum <= result <= maximum:
        raise ApiError(f'{key}: {minimum}–{maximum} aralığında olmalı.')
    return result


def money(data, key='amount', places=2):
    try:
        value = Decimal(str(data.get(key)))
        if not value.is_finite() or value <= 0 or value > Decimal('99999999.99') or value != value.quantize(Decimal(10) ** -places):
            raise ValueError()
        return value
    except (InvalidOperation, ValueError):
        raise ApiError(f'{key}: sıfırdan büyük, en fazla {places} ondalıklı geçerli bir tutar girin.')


def day(data, key, optional=False):
    if optional and not data.get(key):
        return None
    try:
        return date.fromisoformat(str(data.get(key)))
    except ValueError:
        raise ApiError(f'{key}: YYYY-AA-GG biçiminde geçerli tarih girin.')


def choice(data, key, options):
    value = data.get(key)
    if not isinstance(value, str) or value not in options:
        raise ApiError(f'{key}: geçersiz seçim.')
    return value


def boolean(data, key, default=False):
    value = data.get(key, default)
    if not isinstance(value, bool):
        raise ApiError(f'{key}: true veya false olmalı.')
    return value


def email(data):
    value = text(data, 'email', 254).lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', value):
        raise ApiError('Geçerli bir e-posta adresi girin.')
    return value


def password(data, key='password'):
    value = data.get(key)
    if not isinstance(value, str) or not 12 <= len(value) or len(value.encode('utf-8')) > 72:
        raise ApiError('Şifre en az 12 karakter, UTF-8 olarak en fazla 72 bayt olmalı.')
    return value
