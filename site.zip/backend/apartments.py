from .identity import hash_password
from flask import Blueprint, g, jsonify, request
from .db import all_rows, transaction
from .security import admin_required, login_required, scope, audit
from .validation import ApiError, body, text, integer, money, boolean, email, day, choice, password

bp = Blueprint('apartments', __name__, url_prefix='/api')


@bp.get('/apartments')
@login_required
def apartments():
    condition, params = scope()
    query = request.args.get('q', '').strip()[:100]
    params.extend(['%' + query + '%'] * 3)
    return jsonify(all_rows(f'''SELECT a.*,COALESCE((SELECT string_agg(u.full_name, ', ' ORDER BY u.full_name)
        FROM residents r JOIN users u ON u.id=r.user_id
        WHERE r.apartment_id=a.id AND r.move_out IS NULL),'') AS residents
        FROM apartment_balances a WHERE {condition}
        AND (a.block ILIKE %s OR a.number ILIKE %s OR EXISTS (
          SELECT 1 FROM residents r JOIN users u ON u.id=r.user_id
          WHERE r.apartment_id=a.id AND u.full_name ILIKE %s))
        ORDER BY a.block,a.floor,a.number''', params))


def apartment_values(data):
    return (text(data,'block',30), integer(data,'floor',-10,200), text(data,'number',20),
            money(data,'area'),money(data,'land_share',4),boolean(data,'active',True))


@bp.post('/apartments')
@admin_required
def create_apartment():
    values = apartment_values(body())
    with transaction() as cur:
        cur.execute('''INSERT INTO apartments(block,floor,number,area,land_share,active)
                       VALUES(%s,%s,%s,%s,%s,%s) RETURNING *''', values)
        row = cur.fetchone()
        audit(cur,'apartment.create',row['id'])
    return jsonify(row),201


@bp.put('/apartments/<int:row_id>')
@admin_required
def update_apartment(row_id):
    values = apartment_values(body())
    with transaction() as cur:
        cur.execute('''UPDATE apartments SET block=%s,floor=%s,number=%s,area=%s,land_share=%s,active=%s
                       WHERE id=%s RETURNING *''', values+(row_id,))
        row = cur.fetchone()
        if not row:
            raise ApiError('Daire bulunamadı.',404)
        audit(cur,'apartment.update',row_id)
    return jsonify(row)


@bp.delete('/apartments/<int:row_id>')
@admin_required
def delete_apartment(row_id):
    with transaction() as cur:
        cur.execute('DELETE FROM apartments WHERE id=%s RETURNING id',(row_id,))
        if not cur.fetchone():
            raise ApiError('Daire bulunamadı.',404)
        audit(cur,'apartment.delete',row_id)
    return jsonify(message='Daire silindi.')


@bp.get('/residents')
@login_required
def residents():
    condition = 'TRUE' if g.user['role']=='admin' else 'u.id=%s'
    params = [] if g.user['role']=='admin' else [g.user['id']]
    query = '%' + request.args.get('q','').strip()[:100] + '%'
    params.extend([query]*3)
    return jsonify(all_rows(f'''SELECT r.*,u.full_name,u.email,u.active,a.block,a.number
        FROM residents r JOIN users u ON u.id=r.user_id JOIN apartments a ON a.id=r.apartment_id
        WHERE {condition} AND (u.full_name ILIKE %s OR u.email ILIKE %s OR r.phone ILIKE %s)
        ORDER BY u.full_name''',params))


def resident_values(data):
    start,end = day(data,'move_in'),day(data,'move_out',True)
    if end and end<start:
        raise ApiError('Çıkış tarihi giriş tarihinden önce olamaz.')
    return (integer(data,'apartment_id'),text(data,'phone',30,False),
            choice(data,'occupancy',('owner','tenant')),start,end)


@bp.post('/residents')
@admin_required
def create_resident():
    data = body()
    values = resident_values(data)
    full_name,address = text(data,'full_name',120),email(data)
    with transaction() as cur:
        cur.execute('SELECT * FROM users WHERE email=%s FOR UPDATE', (address,))
        existing = cur.fetchone()
        if existing:
            if existing['role'] != 'resident':
                raise ApiError('Yönetici hesabı bu işlemle sakin hesabına dönüştürülemez.')
            user_id = existing['id']
            cur.execute('''UPDATE users SET full_name=%s,active=%s,membership_status='approved',updated_at=NOW()
                           WHERE id=%s''', (full_name,values[-1] is None,user_id))
        else:
            pwd = password(data)
            cur.execute('''INSERT INTO users(full_name,email,password_hash,role,active,membership_status)
                           VALUES(%s,%s,%s,'resident',%s,'approved') RETURNING id''',
                        (full_name,address,hash_password(pwd),values[-1] is None))
            user_id = cur.fetchone()['id']
        cur.execute('''INSERT INTO residents(apartment_id,phone,occupancy,move_in,move_out,user_id)
                       VALUES(%s,%s,%s,%s,%s,%s) RETURNING id''',values+(user_id,))
        row = cur.fetchone()
        cur.execute('DELETE FROM sessions WHERE user_id=%s', (user_id,))
        audit(cur,'resident.create',row['id'])
    return jsonify(row),201


@bp.put('/residents/<int:row_id>')
@admin_required
def update_resident(row_id):
    data=body()
    values=resident_values(data)
    full_name,address = text(data,'full_name',120),email(data)
    active = boolean(data,'active',True) and values[-1] is None
    with transaction() as cur:
        cur.execute('SELECT u.role FROM users u JOIN residents r ON r.user_id=u.id WHERE r.id=%s FOR UPDATE OF u', (row_id,))
        owner = cur.fetchone()
        if owner and owner['role'] != 'resident':
            raise ApiError('Yönetici hesaplarını Kullanıcılar ekranından yönetin.')
        cur.execute('''UPDATE residents SET apartment_id=%s,phone=%s,occupancy=%s,move_in=%s,move_out=%s
                       WHERE id=%s RETURNING user_id''',values+(row_id,))
        row=cur.fetchone()
        if not row:
            raise ApiError('Sakin bulunamadı.',404)
        cur.execute('UPDATE users SET full_name=%s,email=%s,active=%s WHERE id=%s',
                    (full_name,address,active,row['user_id']))
        cur.execute('DELETE FROM sessions WHERE user_id=%s',(row['user_id'],))
        audit(cur,'resident.update',row_id)
    return jsonify(message='Sakin güncellendi.')


@bp.post('/residents/<int:row_id>/password')
@admin_required
def reset_password(row_id):
    pwd=password(body())
    with transaction() as cur:
        cur.execute('''UPDATE users SET password_hash=%s,must_change_password=TRUE
                       WHERE role='resident' AND id=(SELECT user_id FROM residents WHERE id=%s) RETURNING id''',
                    (hash_password(pwd),row_id))
        row=cur.fetchone()
        if not row:
            raise ApiError('Sakin bulunamadı.',404)
        cur.execute('DELETE FROM sessions WHERE user_id=%s',(row['id'],))
        audit(cur,'resident.password_reset',row_id)
    return jsonify(message='Geçici şifre oluşturuldu. Sakine güvenli şekilde iletin.')


@bp.delete('/residents/<int:row_id>')
@admin_required
def delete_resident(row_id):
    with transaction() as cur:
        cur.execute('SELECT u.role FROM users u JOIN residents r ON r.user_id=u.id WHERE r.id=%s FOR UPDATE OF u', (row_id,))
        owner = cur.fetchone()
        if owner and owner['role'] != 'resident':
            raise ApiError('Yönetici hesabına bağlı sakin silinemez. Önce Kullanıcılar ekranından yetkisini değiştirin.', 409)
        cur.execute('DELETE FROM residents WHERE id=%s RETURNING user_id',(row_id,))
        row=cur.fetchone()
        if not row:
            raise ApiError('Sakin bulunamadı.',404)
        # Talep geçmişi korunur; kullanıcı hesabı kişisel bilgilerden arındırılır.
        cur.execute("UPDATE users SET active=FALSE,full_name='Silinen sakin',email=%s,password_hash='' WHERE id=%s",
                    (f'deleted-{row["user_id"]}@invalid.local',row['user_id']))
        cur.execute('DELETE FROM sessions WHERE user_id=%s',(row['user_id'],))
        audit(cur,'resident.delete',row_id)
    return jsonify(message='Sakin silindi ve hesabı kapatıldı.')
