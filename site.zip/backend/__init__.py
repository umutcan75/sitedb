"""Apartman yönetimi REST API paketi."""
