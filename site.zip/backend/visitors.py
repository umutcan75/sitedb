"""Güvenlik görevlileri, beklenen ziyaretçiler ve kapı giriş-çıkış kayıtları."""
from datetime import datetime, timezone, timedelta
from flask import Blueprint, g, jsonify, request
from .db import all_rows, transaction
from .security import site_member_required, admin_required, audit
from .validation import ApiError, body, text, integer, email, password, boolean, choice
from .identity import hash_password

bp=Blueprint('visitors',__name__,url_prefix='/api')


def timestamp(data,key):
    try:
        value=datetime.fromisoformat(str(data.get(key,'')).replace('Z','+00:00'))
        if value.tzinfo is None:
            raise ValueError()
        return value.astimezone(timezone.utc)
    except ValueError:
        raise ApiError(f'{key}: saat dilimi içeren geçerli tarih ve saat girin.')


def gate_required():
    if g.user['role'] not in ('admin','security'):
        raise ApiError('Bu işlem güvenlik görevlisi veya site yöneticisi içindir.',403)


@bp.get('/guards')
@admin_required
def guards():
    return jsonify(all_rows("SELECT id,full_name,email,active,created_at FROM users WHERE role='security' ORDER BY full_name"))


@bp.post('/guards')
@admin_required
def create_guard():
    data=body()
    name,address,hashed=text(data,'full_name',120),email(data),hash_password(password(data))
    with transaction() as cur:
        cur.execute("""INSERT INTO users(full_name,email,password_hash,role,membership_status)
            VALUES(%s,%s,%s,'security','approved') RETURNING id""",(name,address,hashed))
        row=cur.fetchone()
        audit(cur,'guard.created',row['id'])
    return jsonify(row),201


@bp.put('/guards/<int:user_id>')
@admin_required
def update_guard(user_id):
    data=body()
    with transaction() as cur:
        cur.execute("UPDATE users SET full_name=%s,active=%s,updated_at=NOW() WHERE id=%s AND role='security' RETURNING id",
                    (text(data,'full_name',120),boolean(data,'active',True),user_id))
        if not cur.fetchone():
            raise ApiError('Güvenlik görevlisi bulunamadı.',404)
        cur.execute('DELETE FROM sessions WHERE user_id=%s',(user_id,))
        audit(cur,'guard.updated',user_id,{'active':data.get('active',True)})
    return jsonify(message='Görevli hesabı güncellendi.')


@bp.post('/guards/<int:user_id>/password')
@admin_required
def reset_guard_password(user_id):
    hashed=hash_password(password(body()))
    with transaction() as cur:
        cur.execute("UPDATE users SET password_hash=%s,must_change_password=TRUE WHERE id=%s AND role='security' RETURNING id",(hashed,user_id))
        if not cur.fetchone():
            raise ApiError('Güvenlik görevlisi bulunamadı.',404)
        cur.execute('DELETE FROM sessions WHERE user_id=%s',(user_id,))
        audit(cur,'guard.password_reset',user_id)
    return jsonify(message='Geçici şifre kaydedildi.')


@bp.get('/visits/apartments')
@site_member_required
def visit_apartments():
    # Güvenlik ekranında borç veya sakinlerin kişisel hesap bilgileri yer almaz.
    condition='id=%s' if g.user['role']=='resident' else 'TRUE'
    params=(g.user['apartment_id'] or -1,) if g.user['role']=='resident' else ()
    return jsonify(all_rows(f'SELECT id,block,number FROM apartments WHERE active AND {condition} ORDER BY block,number',params))


@bp.get('/visits')
@site_member_required
def visits():
    clauses,params=[],[]
    if g.user['role']=='resident':
        clauses.append('v.apartment_id=%s');params.append(g.user['apartment_id'] or -1)
    if request.args.get('status'):
        clauses.append('v.status=%s');params.append(choice(request.args,'status',('expected','inside','departed','cancelled')))
    query='%'+request.args.get('q','').strip()[:100]+'%'
    clauses.append('(v.guest_name ILIKE %s OR v.vehicle_plate ILIKE %s OR a.block ILIKE %s OR a.number ILIKE %s)')
    params.extend([query]*4)
    return jsonify(all_rows(f'''SELECT v.*,a.block,a.number,u.full_name AS requested_by,
        (v.status='expected' AND v.expected_until<NOW()) AS expired
        FROM visits v JOIN apartments a ON a.id=v.apartment_id LEFT JOIN users u ON u.id=v.created_by
        WHERE {' AND '.join(clauses)} ORDER BY CASE v.status WHEN 'inside' THEN 0 WHEN 'expected' THEN 1 ELSE 2 END,
        v.expected_at DESC,v.id DESC LIMIT 500''',params))


@bp.post('/visits')
@site_member_required
def create_visit():
    data=body()
    is_resident=g.user['role']=='resident'
    aid=g.user['apartment_id'] if is_resident else integer(data,'apartment_id')
    if not aid:
        raise ApiError('Önce hesabınızın bir daireye bağlanması gerekiyor.')
    now=datetime.now(timezone.utc)
    start=timestamp(data,'expected_at') if is_resident else now
    end=timestamp(data,'expected_until') if is_resident else now+timedelta(hours=12)
    if end<=start or end<=now or end-start>timedelta(days=7):
        raise ApiError('Ziyaret bitişi başlangıçtan ve şu andan sonra olmalı; aralık en fazla 7 gün olabilir.')
    name,count,plate,purpose=text(data,'guest_name',120),integer(data,'guest_count',1,20),text(data,'vehicle_plate',20,False),text(data,'purpose',500,False)
    with transaction() as cur:
        cur.execute('SELECT id FROM apartments WHERE id=%s AND active',(aid,))
        if not cur.fetchone():
            raise ApiError('Aktif daire bulunamadı.',404)
        cur.execute('''INSERT INTO visits(apartment_id,guest_name,guest_count,vehicle_plate,purpose,expected_at,expected_until,
            source,status,created_by,arrived_at,arrived_by,security_note)
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *''',
            (aid,name,count,plate.upper(),purpose,start,end,'resident' if is_resident else 'gate',
             'expected' if is_resident else 'inside',g.user['id'],None if is_resident else now,
             None if is_resident else g.user['id'],'' if is_resident else text(data,'security_note',1000,False)))
        row=cur.fetchone()
        audit(cur,'visit.created',row['id'],{'source':row['source'],'apartment_id':aid})
    return jsonify(row),201


@bp.post('/visits/<int:visit_id>/transition')
@site_member_required
def transition(visit_id):
    data=body()
    action=choice(data,'action',('check_in','check_out','cancel','note'))
    note=text(data,'security_note',1000,False)
    if action!='cancel':
        gate_required()
    with transaction() as cur:
        cur.execute('SELECT * FROM visits WHERE id=%s FOR UPDATE',(visit_id,))
        row=cur.fetchone()
        if not row or (g.user['role']=='resident' and row['created_by']!=g.user['id']):
            raise ApiError('Ziyaret kaydı bulunamadı.',404)
        if action=='check_in':
            now=datetime.now(timezone.utc)
            if row['status']!='expected' or not row['expected_at']<=now<=row['expected_until']:
                raise ApiError('Giriş yalnızca geçerli zaman aralığındaki beklenen ziyaretçi için yapılabilir.',409)
            cur.execute("UPDATE visits SET status='inside',arrived_at=NOW(),arrived_by=%s,security_note=%s,updated_at=NOW() WHERE id=%s",(g.user['id'],note or row['security_note'],visit_id))
        elif action=='check_out':
            if row['status']!='inside':
                raise ApiError('Yalnızca içerideki ziyaretçi için çıkış kaydı tutulabilir.',409)
            cur.execute("UPDATE visits SET status='departed',departed_at=NOW(),departed_by=%s,security_note=%s,updated_at=NOW() WHERE id=%s",(g.user['id'],note or row['security_note'],visit_id))
        elif action=='cancel':
            if row['status']!='expected':
                raise ApiError('Yalnızca henüz giriş yapmamış ziyaret iptal edilebilir.',409)
            cur.execute("UPDATE visits SET status='cancelled',updated_at=NOW() WHERE id=%s",(visit_id,))
        else:
            cur.execute('UPDATE visits SET security_note=%s,updated_at=NOW() WHERE id=%s',(note,visit_id))
        audit(cur,'visit.'+action,visit_id)
    return jsonify(message='Ziyaret kaydı güncellendi.')
