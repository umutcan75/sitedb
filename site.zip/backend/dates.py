"""Türkiye iş tarihi, sunucunun yerel saat diliminden bağımsızdır."""
from datetime import datetime, timezone, timedelta


def today():
    return datetime.now(timezone(timedelta(hours=3))).date()
