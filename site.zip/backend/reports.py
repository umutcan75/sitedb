import csv
import io
from .dates import today
from decimal import Decimal
from flask import Blueprint, g, jsonify, request, Response
from .db import all_rows, one_row
from .security import admin_required, login_required, scope
from .validation import integer

bp=Blueprint('reports',__name__,url_prefix='/api')


def financial_report(year, month=None):
    # Tahsilat gelirleri ayrı tablodan eklenir. Aidat tahakkuku kasaya girmez.
    rows=all_rows('''WITH months AS (SELECT generate_series(1,12) AS month),
        p AS (SELECT EXTRACT(MONTH FROM paid_on)::int AS month,sum(amount) total
              FROM payments WHERE voided_at IS NULL AND status='approved' AND EXTRACT(YEAR FROM paid_on)=%s GROUP BY 1),
        l AS (SELECT EXTRACT(MONTH FROM entry_date)::int AS month,
                     sum(amount) FILTER(WHERE c.kind='income') income,
                     sum(amount) FILTER(WHERE c.kind='expense') expense
              FROM ledger_entries e JOIN categories c ON c.id=e.category_id
              WHERE EXTRACT(YEAR FROM entry_date)=%s GROUP BY 1)
        SELECT m.month,COALESCE(p.total,0) collections,COALESCE(l.income,0) other_income,
               COALESCE(l.expense,0) expense,COALESCE(p.total,0)+COALESCE(l.income,0) income,
               COALESCE(p.total,0)+COALESCE(l.income,0)-COALESCE(l.expense,0) net
        FROM months m LEFT JOIN p ON p.month=m.month LEFT JOIN l ON l.month=m.month ORDER BY m.month''',(year,year))
    if month:
        rows=[r for r in rows if r['month']==month]
    totals={key:sum((r[key] for r in rows),Decimal(0)) for key in ('collections','other_income','expense','income','net')}
    return dict(year=year,month=month,rows=rows,totals=totals)


@bp.get('/dashboard')
@login_required
def dashboard():
    condition,params=scope()
    stats=one_row(f'''SELECT count(*) FILTER(WHERE active) apartments,COALESCE(sum(GREATEST(balance,0)),0) debt,
                     COALESCE(sum(GREATEST(-balance,0)),0) credit,COALESCE(sum(overdue),0) overdue
                     FROM apartment_balances a WHERE {condition}''',params)
    payment_condition='TRUE' if g.user['role']=='admin' else 'apartment_id=%s'
    payment_params=[] if g.user['role']=='admin' else [g.user['apartment_id'] or -1]
    stats['monthly_collections']=one_row(f'''SELECT COALESCE(sum(amount),0) total FROM payments
        WHERE voided_at IS NULL AND status='approved' AND date_trunc('month',paid_on)=date_trunc('month',CURRENT_DATE)
        AND {payment_condition}''',payment_params)['total']
    stats['open_tickets']=one_row('SELECT count(*) total FROM tickets WHERE status<>\'closed\''+
        ('' if g.user['role']=='admin' else ' AND user_id=%s'),[] if g.user['role']=='admin' else [g.user['id']])['total']
    if g.user['role']=='admin':
        stats['cash']=one_row('''SELECT (SELECT COALESCE(sum(amount),0) FROM payments WHERE voided_at IS NULL AND status='approved')+
            (SELECT COALESCE(sum(CASE WHEN c.kind='income' THEN e.amount ELSE -e.amount END),0)
             FROM ledger_entries e JOIN categories c ON c.id=e.category_id) total''')['total']
        stats['chart']=financial_report(today().year)['rows']
    else:
        stats['chart']=all_rows('''SELECT to_char(period,'YYYY-MM') period,sum(amount) amount FROM charges
                                  WHERE apartment_id=%s GROUP BY period ORDER BY period DESC LIMIT 12''',payment_params)[::-1]
    return jsonify(stats)


def debtors():
    return all_rows('''SELECT a.id,a.block,a.number,a.charged,a.paid,a.balance,a.overdue,
        COALESCE((SELECT string_agg(u.full_name,', ') FROM residents r JOIN users u ON u.id=r.user_id
                  WHERE r.apartment_id=a.id AND r.move_out IS NULL),'') residents
        FROM apartment_balances a WHERE a.balance>0 ORDER BY a.overdue DESC,a.balance DESC''')


@bp.get('/reports/debtors')
@admin_required
def debtors_report():
    rows=debtors()
    if request.args.get('overdue')=='true':
        rows=[r for r in rows if r['overdue']>0]
    return jsonify(rows)


@bp.get('/reports/financial')
@admin_required
def financial():
    return jsonify(financial_report(integer(request.args,'year',2000,2100),
        integer(request.args,'month',1,12) if request.args.get('month') else None))


def csv_response(headers, rows, filename):
    stream=io.StringIO(newline='')
    writer=csv.writer(stream,delimiter=';')
    writer.writerow(headers)
    for row in rows:
        safe=[]
        for value in row:
            if isinstance(value,Decimal):
                safe.append(format(value,'.2f').replace('.',','))
            else:
                value='' if value is None else str(value)
                # Excel formül enjeksiyonuna karşı kullanıcı metinlerini etkisizleştir.
                safe.append("'"+value if value.lstrip().startswith(('=','+','-','@')) or value.startswith(('\t','\r','\n')) else value)
        writer.writerow(safe)
    return Response('\ufeff'+stream.getvalue(),content_type='text/csv; charset=utf-8',
                    headers={'Content-Disposition':f'attachment; filename="{filename}"','Cache-Control':'no-store'})


@bp.get('/reports/debtors.csv')
@admin_required
def debtors_csv():
    rows=debtors()
    if request.args.get('overdue')=='true':
        rows=[r for r in rows if r['overdue']>0]
    return csv_response(['Blok','Daire','Sakinler','Toplam aidat','Tahsilat','Borç','Geciken'],
        [[r[k] for k in ('block','number','residents','charged','paid','balance','overdue')] for r in rows],'borclular.csv')


@bp.get('/reports/financial.csv')
@admin_required
def financial_csv():
    report=financial_report(integer(request.args,'year',2000,2100),integer(request.args,'month',1,12) if request.args.get('month') else None)
    return csv_response(['Ay','Aidat tahsilatı','Diğer gelir','Toplam gelir','Gider','Net'],
        [[r[k] for k in ('month','collections','other_income','income','expense','net')] for r in report['rows']],'gelir-gider.csv')


@bp.get('/apartments/<int:row_id>/statement.csv')
@login_required
def statement_csv(row_id):
    from .finance import statement
    data=statement(row_id).get_json()
    return csv_response(['Tarih','Açıklama','Borç','Ödeme','Bakiye','Makbuz'],
        [[r['date'],r['description'],Decimal(r['debit']),Decimal(r['credit']),Decimal(r['balance']),r['receipt_no']] for r in data['rows']],
        f'daire-{row_id}-ekstre.csv')


@bp.get('/audit')
@admin_required
def audit_log():
    return jsonify(all_rows('''SELECT a.*,u.full_name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id
                              ORDER BY a.id DESC LIMIT 200'''))
