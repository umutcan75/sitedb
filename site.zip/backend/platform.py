"""Platform sahibi: yönetici kabulü, site kaydı ve site-yönetici eşleştirmesi."""
from flask import Blueprint, jsonify, g
from .db import all_rows, one_row, transaction
from .security import super_admin_required, audit
from .identity import hash_password
from .validation import body, text, email, password, boolean, integer, ApiError

bp = Blueprint('platform', __name__, url_prefix='/api/platform')


@bp.get('/overview')
@super_admin_required
def overview():
    return jsonify(one_row('''SELECT
        (SELECT count(*) FROM sites) sites,
        (SELECT count(*) FROM sites WHERE active) active_sites,
        (SELECT count(*) FROM users WHERE role='admin') managers,
        (SELECT count(*) FROM users WHERE role='admin' AND membership_status='pending' AND active) pending,
        (SELECT count(*) FROM users WHERE role='resident') residents,
        (SELECT count(*) FROM apartments) apartments'''))


@bp.get('/sites')
@super_admin_required
def sites():
    return jsonify(all_rows('''SELECT s.*,
        (SELECT count(*) FROM apartments a WHERE a.site_id=s.id) apartments,
        (SELECT count(*) FROM users u WHERE u.site_id=s.id AND u.role='resident') residents,
        (SELECT string_agg(u.full_name || ' (' || u.email || ')', ', ' ORDER BY u.full_name)
         FROM users u WHERE u.site_id=s.id AND u.role='admin' AND u.active) managers
        FROM sites s ORDER BY s.name,s.id'''))


@bp.post('/sites')
@super_admin_required
def create_site():
    data = body()
    with transaction() as cur:
        cur.execute('INSERT INTO sites(name,address) VALUES(%s,%s) RETURNING *',
                    (text(data,'name',160),text(data,'address',500,False)))
        row = cur.fetchone()
        audit(cur,'site.created',row['id'],{'name':row['name']})
    return jsonify(row),201


@bp.put('/sites/<int:site_id>')
@super_admin_required
def update_site(site_id):
    data = body()
    with transaction() as cur:
        cur.execute('''UPDATE sites SET name=%s,address=%s,active=%s,updated_at=NOW()
                       WHERE id=%s RETURNING *''',
                    (text(data,'name',160),text(data,'address',500,False),boolean(data,'active',True),site_id))
        row = cur.fetchone()
        if not row:
            raise ApiError('Site bulunamadı.',404)
        if not row['active']:
            cur.execute('DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE site_id=%s)',(site_id,))
        audit(cur,'site.updated',site_id,{'name':row['name'],'active':row['active']})
    return jsonify(row)


@bp.get('/managers')
@super_admin_required
def managers():
    return jsonify(all_rows('''SELECT u.id,u.full_name,u.email,u.role,u.active,u.membership_status,
        u.site_id,u.requested_site,u.created_at,s.name AS site_name FROM users u
        LEFT JOIN sites s ON s.id=u.site_id WHERE u.role='admin'
        ORDER BY (u.membership_status='pending') DESC,u.created_at DESC'''))


@bp.post('/managers')
@super_admin_required
def create_manager():
    data = body()
    name,address,pwd = text(data,'full_name',120),email(data),password(data)
    with transaction() as cur:
        cur.execute('''INSERT INTO users(full_name,email,password_hash,role,membership_status,site_id)
            VALUES(%s,%s,%s,'admin','pending',NULL) ON CONFLICT(email) DO NOTHING RETURNING id''',
                    (name,address,hash_password(pwd)))
        row = cur.fetchone()
        if not row:
            raise ApiError('Bu e-posta zaten kayıtlı. Mevcut yönetici başvurusunu listeden seçin.',409)
        audit(cur,'manager.created',row['id'],{'email':address})
    return jsonify(id=row['id'],message='Yönetici oluşturuldu. Şimdi bir siteye bağlayıp onaylayın.'),201


@bp.put('/managers/<int:user_id>')
@super_admin_required
def update_manager(user_id):
    data = body()
    name = text(data,'full_name',120)
    active = boolean(data,'active',True)
    approved = boolean(data,'approved',False)
    site_id = integer(data,'site_id') if data.get('site_id') else None
    if approved and not site_id:
        raise ApiError('Yöneticiyi onaylamak için önce sitesini seçin.')
    with transaction() as cur:
        cur.execute('SELECT pg_advisory_xact_lock(817220603)')
        cur.execute("SELECT * FROM users WHERE id=%s AND role='admin' FOR UPDATE",(user_id,))
        before = cur.fetchone()
        if not before:
            raise ApiError('Site yöneticisi bulunamadı.',404)
        if site_id:
            cur.execute('SELECT id,active FROM sites WHERE id=%s FOR SHARE',(site_id,))
            site = cur.fetchone()
            if not site or (approved and active and not site['active']):
                raise ApiError('Onay ve erişim için aktif bir site seçin.')
        if before['site_id'] and before['site_id'] != site_id:
            # Geçmiş mali kayıtların kullanıcı ve site ilişkisi korunur.
            cur.execute('''SELECT EXISTS(SELECT 1 FROM residents WHERE user_id=%s)
                OR EXISTS(SELECT 1 FROM charges WHERE created_by=%s)
                OR EXISTS(SELECT 1 FROM payments WHERE created_by=%s OR voided_by=%s)
                OR EXISTS(SELECT 1 FROM ledger_entries WHERE created_by=%s)
                OR EXISTS(SELECT 1 FROM announcements WHERE created_by=%s)
                OR EXISTS(SELECT 1 FROM tickets WHERE user_id=%s) AS used''',(user_id,)*7)
            if cur.fetchone()['used']:
                raise ApiError('Bu yöneticinin sitesinde işlem geçmişi var. Başka siteye taşımak yerine o site için ayrı yönetici hesabı oluşturun.',409)
        status = 'approved' if approved else 'pending'
        cur.execute('''UPDATE users SET full_name=%s,site_id=%s,membership_status=%s,active=%s,
                       updated_at=NOW() WHERE id=%s''',(name,site_id,status,active,user_id))
        cur.execute('DELETE FROM sessions WHERE user_id=%s',(user_id,))
        audit(cur,'manager.updated',user_id,{'old_site_id':before['site_id'],'site_id':site_id,
                                         'status':status,'active':active})
    return jsonify(message='Yönetici kaydedildi. Değişiklikler yeniden giriş yaptığında uygulanır.')


@bp.post('/managers/<int:user_id>/password')
@super_admin_required
def reset_manager_password(user_id):
    hashed = hash_password(password(body()))
    with transaction() as cur:
        cur.execute("UPDATE users SET password_hash=%s,must_change_password=TRUE,updated_at=NOW() WHERE id=%s AND role='admin' RETURNING id",(hashed,user_id))
        if not cur.fetchone():
            raise ApiError('Site yöneticisi bulunamadı.',404)
        cur.execute('DELETE FROM sessions WHERE user_id=%s',(user_id,))
        audit(cur,'manager.password_reset',user_id)
    return jsonify(message='Geçici şifre kaydedildi; ilk girişte değiştirilmesi gerekir.')


@bp.get('/audit')
@super_admin_required
def platform_audit():
    return jsonify(all_rows('''SELECT a.*,u.full_name,s.name AS site_name FROM audit_log a
        LEFT JOIN users u ON u.id=a.user_id LEFT JOIN sites s ON s.id=a.site_id
        ORDER BY a.id DESC LIMIT 300'''))
