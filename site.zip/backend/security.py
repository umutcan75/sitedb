"""Rol denetimi ve daireye göre erişim süzme, sunucu tarafında yapılır."""
from functools import wraps
import hashlib
import secrets
from flask import g, request, session
from psycopg2.extras import Json
from .db import one_row
from .validation import ApiError


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def load_user():
    g.user = None
    if session.get('sid'):
        g.user = one_row('''SELECT u.id,u.full_name,u.email,u.role,u.must_change_password,
                                  u.membership_status,u.site_id,st.name AS site_name,st.active AS site_active,
                                  u.requested_site,r.apartment_id,s.authentication_methods
                           FROM sessions s JOIN users u ON u.id=s.user_id
                           LEFT JOIN sites st ON st.id=u.site_id
                           LEFT JOIN residents r ON r.user_id=u.id AND r.move_out IS NULL
                           WHERE s.token_hash=%s AND s.expires_at>NOW() AND u.active''',
                         (digest(session['sid']),))


def csrf_check():
    if request.method not in ('GET', 'HEAD', 'OPTIONS') and request.path.startswith('/api/'):
        expected = session.get('csrf', '')
        actual = request.headers.get('X-CSRF-Token', '')
        if not expected or not secrets.compare_digest(expected, actual):
            raise ApiError('Güvenlik anahtarı geçersiz. Sayfayı yenileyin.', 403)


def account_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not g.user:
            raise ApiError('Oturum açmanız gerekiyor.', 401)
        return fn(*args, **kwargs)
    return wrapped


def site_member_required(fn):
    @wraps(fn)
    @account_required
    def wrapped(*args, **kwargs):
        if g.user['must_change_password']:
            raise ApiError('Devam etmek için geçici şifrenizi değiştirin.', 403)
        if g.user['membership_status'] != 'approved':
            raise ApiError('Hesabınız yönetici onayı bekliyor.', 403)
        if g.user['role'] == 'super_admin':
            raise ApiError('Bu işlem site yöneticisi paneline aittir.', 403)
        if not g.user.get('site_id') or not g.user.get('site_active'):
            raise ApiError('Hesabınıza aktif bir site atanması gerekiyor.', 403)
        return fn(*args, **kwargs)
    return wrapped


def login_required(fn):
    @wraps(fn)
    @site_member_required
    def wrapped(*args, **kwargs):
        if g.user['role'] not in ('admin','resident'):
            raise ApiError('Bu ekran güvenlik görevlisi yetkisine dahil değil.',403)
        return fn(*args, **kwargs)
    return wrapped


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapped(*args, **kwargs):
        if g.user['role'] != 'admin':
            raise ApiError('Bu işlem için yönetici yetkisi gerekir.', 403)
        return fn(*args, **kwargs)
    return wrapped


def apartment_access(apartment_id):
    if g.user['role'] != 'admin' and g.user['apartment_id'] != apartment_id:
        raise ApiError('Bu daireye erişim yetkiniz yok.', 403)
    row = one_row('SELECT * FROM apartments WHERE id=%s', (apartment_id,))
    if not row:
        raise ApiError('Daire bulunamadı.', 404)
    return row


def scope(alias='a'):
    # alias yalnızca kodun içinden gelir; kullanıcı verisi SQL'e eklenmez.
    if g.user['role'] == 'admin':
        return 'TRUE', []
    return f'{alias}.id=%s', [g.user['apartment_id'] or -1]


def audit(cur, action, entity_id=None, detail=None):
    user = getattr(g, 'user', None)
    cur.execute('INSERT INTO audit_log(user_id,action,entity_id,detail,site_id) VALUES(%s,%s,%s,%s,%s)',
                (user['id'] if user else None, action, entity_id, Json(detail or {}), user.get('site_id') if user else None))


def super_admin_required(fn):
    @wraps(fn)
    @account_required
    def wrapped(*args, **kwargs):
        if g.user['role'] != 'super_admin' or g.user['membership_status'] != 'approved':
            raise ApiError('Bu işlem yalnızca süper admin tarafından yapılabilir.', 403)
        if g.user['must_change_password']:
            raise ApiError('Önce geçici şifrenizi değiştirin.', 403)
        return fn(*args, **kwargs)
    return wrapped
