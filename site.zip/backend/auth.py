import secrets
from flask import Blueprint, g, jsonify, session
from .db import transaction
from .identity import password_authenticator, hash_password
from .rate_limit import enforce_limit, enforce_ip, clear_limit
from .security import digest, account_required, audit
from .validation import ApiError, body, email, password, text

bp = Blueprint('auth', __name__, url_prefix='/api/auth')


@bp.get('/csrf')
def csrf():
    session.setdefault('csrf', secrets.token_urlsafe(32))
    return jsonify(csrf_token=session['csrf'])


@bp.post('/register')
def register():
    g.user = None
    enforce_ip('register', 10, 3600)
    data = body()
    address, supplied = email(data), password(data)
    enforce_limit('register-email', address, 3, 3600)
    name = text(data, 'full_name', 120)
    requested_site = text(data, 'site_name', 160)
    hashed = hash_password(supplied)
    with transaction() as cur:
        # Başvurunun rolü sabittir; kabul ve site ataması yalnızca platform sahibindedir.
        cur.execute('''INSERT INTO users(full_name,email,password_hash,role,active,
            must_change_password,membership_status,requested_site,site_id)
            VALUES(%s,%s,%s,'admin',TRUE,FALSE,'pending',%s,NULL)
            ON CONFLICT(email) DO NOTHING RETURNING id''', (name, address, hashed, requested_site))
        row = cur.fetchone()
        if row:
            audit(cur, 'auth.register', row['id'])
    return jsonify(message='Yönetici başvurunuz alındı. Site ataması ve onay için platform sahibinin işlemini bekleyin.'), 202


@bp.post('/login')
def login():
    g.user = None
    enforce_ip('login', 100, 900)
    data = body()
    address = email(data)
    enforce_limit('login-email', address, 10, 900)
    with transaction() as cur:
        cur.execute('SELECT * FROM users WHERE email=%s FOR UPDATE', (address,))
        user = cur.fetchone()
        identity = password_authenticator.authenticate(user, data.get('password', ''))
        if identity is None:
            audit(cur, 'auth.login_failed')
        else:
            if session.get('sid'):
                cur.execute('DELETE FROM sessions WHERE token_hash=%s', (digest(session['sid']),))
            session.clear()
            session['sid'] = secrets.token_urlsafe(32)
            session['csrf'] = secrets.token_urlsafe(32)
            session.permanent = True
            cur.execute('DELETE FROM sessions WHERE expires_at<NOW()')
            cur.execute('''INSERT INTO sessions(token_hash,user_id,expires_at,authentication_methods)
                VALUES(%s,%s,NOW()+INTERVAL '8 hours',%s)''',
                (digest(session['sid']), identity.user_id, list(identity.methods)))
            g.user = user
            audit(cur, 'auth.login', identity.user_id, {'methods': list(identity.methods)})
    if identity is None:
        raise ApiError('E-posta veya şifre hatalı.', 401)
    clear_limit('login-email', address)
    return jsonify(csrf_token=session['csrf'], must_change_password=user['must_change_password'],
                   membership_status=user['membership_status'])


@bp.get('/me')
@account_required
def me():
    return jsonify(g.user)


@bp.post('/logout')
@account_required
def logout():
    with transaction() as cur:
        cur.execute('DELETE FROM sessions WHERE token_hash=%s', (digest(session['sid']),))
        audit(cur, 'auth.logout', g.user['id'])
    session.clear()
    return jsonify(message='Oturum kapatıldı.')


@bp.post('/password')
@account_required
def change_password():
    enforce_limit('password-change', str(g.user['id']), 5, 900)
    data = body()
    new = password(data, 'new_password')
    old = data.get('current_password', '')
    with transaction() as cur:
        cur.execute('SELECT * FROM users WHERE id=%s FOR UPDATE', (g.user['id'],))
        user = cur.fetchone()
        if not password_authenticator.authenticate(user, old):
            raise ApiError('Mevcut şifre hatalı.')
        if old == new:
            raise ApiError('Yeni şifre mevcut şifreden farklı olmalı.')
        cur.execute('''UPDATE users SET password_hash=%s,must_change_password=FALSE,updated_at=NOW()
            WHERE id=%s''', (hash_password(new), g.user['id']))
        cur.execute('DELETE FROM sessions WHERE user_id=%s AND token_hash<>%s',
                    (g.user['id'], digest(session['sid'])))
        audit(cur, 'auth.password_changed', g.user['id'])
    return jsonify(message='Şifreniz değiştirildi; diğer oturumlar kapatıldı.')


@bp.put('/profile')
@account_required
def profile():
    full_name = text(body(), 'full_name', 120)
    with transaction() as cur:
        cur.execute('UPDATE users SET full_name=%s,updated_at=NOW() WHERE id=%s', (full_name, g.user['id']))
        audit(cur, 'auth.profile_updated', g.user['id'])
    return jsonify(message='Profiliniz güncellendi.')
