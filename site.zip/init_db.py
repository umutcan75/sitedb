"""Mevcut PostgreSQL veritabanını veri kaybetmeden kurar ve sürümler."""
import psycopg2
from psycopg2 import sql
from backend.config import ROOT, load_config, db_params


def initialize(config_path=None):
    config = load_config(config_path)
    params = db_params(config)
    connection = psycopg2.connect(**db_params(config, 'postgres'))
    try:
        connection.autocommit = True
        with connection.cursor() as cursor:
            cursor.execute('SELECT pg_advisory_lock(817220601)')
            try:
                cursor.execute('SELECT 1 FROM pg_database WHERE datname=%s', (params['dbname'],))
                if not cursor.fetchone():
                    cursor.execute(sql.SQL("CREATE DATABASE {} ENCODING 'UTF8' TEMPLATE template0")
                                   .format(sql.Identifier(params['dbname'])))
            finally:
                cursor.execute('SELECT pg_advisory_unlock(817220601)')
    finally:
        connection.close()
    connection = psycopg2.connect(**params)
    try:
        with connection:
            with connection.cursor() as cursor:
                cursor.execute('SELECT pg_advisory_xact_lock(817220602)')
                cursor.execute((ROOT / 'database' / 'schema.sql').read_text(encoding='utf-8'))
                cursor.execute('''CREATE TABLE IF NOT EXISTS sitedb.schema_migrations (
                    version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())''')
                for migration in sorted((ROOT / 'database' / 'migrations').glob('*.sql')):
                    cursor.execute('SELECT 1 FROM sitedb.schema_migrations WHERE version=%s', (migration.name,))
                    if cursor.fetchone():
                        continue
                    cursor.execute(migration.read_text(encoding='utf-8'))
                    cursor.execute('INSERT INTO sitedb.schema_migrations(version) VALUES(%s)', (migration.name,))
                cursor.execute((ROOT / 'database' / 'views.sql').read_text(encoding='utf-8'))
        print('Veritabanı şeması güncel. Mevcut kayıtlar korundu.')
    finally:
        connection.close()


if __name__ == '__main__':
    initialize()
