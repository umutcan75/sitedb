-- Mevcut daire ve mali veriler korunarak hesap yönetimi genişletilir.
ALTER TABLE sitedb.users ADD COLUMN IF NOT EXISTS membership_status VARCHAR(16)
    NOT NULL DEFAULT 'pending' CHECK (membership_status IN ('pending','approved'));
ALTER TABLE sitedb.users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();
ALTER TABLE sitedb.sessions ADD COLUMN IF NOT EXISTS authentication_methods TEXT[]
    NOT NULL DEFAULT ARRAY['password']::text[];
ALTER TABLE sitedb.sessions ADD COLUMN IF NOT EXISTS authenticated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();
UPDATE sitedb.users u SET membership_status='approved'
WHERE u.role='admin' OR EXISTS (SELECT 1 FROM sitedb.residents r WHERE r.user_id=u.id);
CREATE INDEX IF NOT EXISTS ix_users_membership ON sitedb.users(membership_status,created_at);
CREATE INDEX IF NOT EXISTS ix_sessions_expires ON sitedb.sessions(expires_at);
CREATE TABLE IF NOT EXISTS sitedb.rate_limits (
    key CHAR(64) PRIMARY KEY,
    count INTEGER NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_rate_limits_expiry ON sitedb.rate_limits(expires_at);
-- Denetim kaydı uygulama içinden değiştirilemez veya silinemez.
CREATE OR REPLACE FUNCTION sitedb.protect_audit_log() RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Denetim kayıtları değiştirilemez.' USING ERRCODE='42501';
END;
$$;
DROP TRIGGER IF EXISTS audit_log_immutable ON sitedb.audit_log;
CREATE TRIGGER audit_log_immutable BEFORE UPDATE OR DELETE ON sitedb.audit_log
FOR EACH ROW EXECUTE FUNCTION sitedb.protect_audit_log();
