-- Hesap rolü veya sitesi değişse de makbuzdaki tahsil eden bilgisi korunur.
ALTER TABLE sitedb.payments ADD COLUMN received_by_name VARCHAR(120) NOT NULL DEFAULT '';
UPDATE sitedb.payments p SET received_by_name=u.full_name FROM sitedb.users u WHERE u.id=p.created_by;
