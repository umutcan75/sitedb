SET search_path TO sitedb, public;
-- Ödemeler dairenin en eski borcuna mahsup edilir; fazla ödeme alacak olarak kalır.
CREATE OR REPLACE VIEW apartment_balances WITH (security_invoker=TRUE) AS
SELECT a.id,a.block,a.floor,a.number,a.area,a.land_share,a.active,a.created_at, COALESCE(c.total,0)::numeric(12,2) AS charged,
       COALESCE(p.total,0)::numeric(12,2) AS paid,
       (COALESCE(c.total,0)-COALESCE(p.total,0))::numeric(12,2) AS balance,
       GREATEST(COALESCE(c.overdue,0)-COALESCE(p.total,0),0)::numeric(12,2) AS overdue
FROM apartments a
LEFT JOIN (SELECT apartment_id,sum(amount) total,
                  sum(amount) FILTER (WHERE due_date < CURRENT_DATE) overdue
           FROM charges GROUP BY apartment_id) c ON c.apartment_id=a.id
LEFT JOIN (SELECT apartment_id,sum(amount) total FROM payments WHERE voided_at IS NULL AND status='approved'
           GROUP BY apartment_id) p ON p.apartment_id=a.id;
