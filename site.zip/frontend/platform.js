"use strict";
// Platform sahibinin çalışma alanı, site yöneticisinin ekranlarından ayrıdır.
const platformNav = [
  ["superadmin", "Platform özeti", "grid"],
  ["platform-managers", "Yöneticiler & başvurular", "users"],
  ["platform-sites", "Siteler", "building"],
  ["platform-audit", "İşlem geçmişi", "clock"],
  ["settings", "Hesabım", "settings"],
];
const platformState = { sites: [], managers: [] };

pages.superadmin = async () => {
  const data = await api("/platform/overview");
  return {
    html:
      heading(
        "Süper admin paneli",
        "Site kabulü ve yönetici atamalarının tamamı sizin kontrolünüzde.",
      ) +
      `<div class="stat-grid">${stat("Kayıtlı site", data.sites, `${data.active_sites} aktif site`, "building", true)}${stat("Site yöneticisi", data.managers, "Platforma kayıtlı yöneticiler", "users")}${stat("Onay bekleyen", data.pending, "İncelenecek yönetici başvuruları", "clock")}${stat("Site sakini", data.residents, `${data.apartments} daire`, "home")}</div>
    <section class="panel platform-guide"><span class="eyebrow muted">SİSTEME DAHİL ETME</span><h2>Yeni bir siteyi üç adımda açın.</h2><div class="platform-steps">
    <a href="#platform-managers"><strong>01 · Yöneticiyi ekleyin</strong><p>Ad soyad, e-posta ve geçici şifre ile hesap açın veya gelen başvuruyu seçin.</p></a>
    <a href="#platform-sites"><strong>02 · Siteyi kaydedin</strong><p>Sitenin gerçek adını ve adresini girin. Her sitenin kayıtları ayrı tutulur.</p></a>
    <a href="#platform-managers"><strong>03 · Bağlayın ve onaylayın</strong><p>Yöneticinin sitesini seçip erişimini onaylayın. Daire ve sakin kayıtlarını yöneticisi tamamlasın.</p></a></div>
    <div class="actions"><a class="button primary" href="#platform-managers">Yöneticiler ve başvurular →</a><a class="button" href="#platform-sites">Siteleri yönet</a></div></section>`,
  };
};

pages["platform-sites"] = async () => {
  platformState.sites = await api("/platform/sites");
  return {
    html:
      heading(
        "Siteler",
        "Site bilgilerini düzenleyin; erişimi açın veya durdurun.",
        button("Site ekle", "platform-site-new"),
      ) +
      `<section class="panel">${table(
        ["Site", "Adres", "Yöneticiler", "Daire / sakin", "Durum", "İşlem"],
        platformState.sites.map((s) => [
          `<strong>${e(s.name)}</strong>`,
          e(s.address || "—"),
          e(s.managers || "Yönetici atanmamış"),
          `${s.apartments} / ${s.residents}`,
          badge(s.active ? "Aktif" : "Durduruldu", s.active ? "green" : "red"),
          button(
            "Düzenle",
            "platform-site-edit",
            `data-id="${s.id}"`,
            "small",
            "",
          ),
        ]),
      )}</section>`,
  };
};

pages["platform-managers"] = async () => {
  [platformState.managers, platformState.sites] = await Promise.all([
    api("/platform/managers"),
    api("/platform/sites"),
  ]);
  const rows = platformState.managers;
  const render = (list) =>
    table(
      ["Yönetici", "Başvurulan site", "Bağlı site", "Durum", "İşlemler"],
      list.map((u) => [
        `<strong>${e(u.full_name)}</strong><span class="cell-sub">${e(u.email)}</span>`,
        e(u.requested_site || "—"),
        e(u.site_name || "Site seçilmedi"),
        badge(
          !u.active
            ? "Reddedildi / kapalı"
            : u.membership_status === "approved"
              ? "Onaylı"
              : "Onay bekliyor",
          !u.active
            ? "red"
            : u.membership_status === "approved"
              ? "green"
              : "amber",
        ),
        `<div class="row-actions">${button("Site bağla / yetkilendir", "platform-manager-edit", `data-id="${u.id}"`, "small", "")}${button("Geçici şifre", "platform-manager-password", `data-id="${u.id}"`, "small", "")}</div>`,
      ]),
    );
  return {
    html:
      heading(
        "Yöneticiler ve başvurular",
        "Sisteme kabulü siz yaparsınız. Yönetici yalnızca bağlandığı sitede işlem yapar.",
        button("Yönetici ekle", "platform-manager-new"),
      ) +
      `<div class="toolbar"><input id="manager-search" class="search" aria-label="Yönetici veya site ara"><label class="checkbox"><input id="manager-pending" type="checkbox">Yalnızca bekleyenler</label></div><section id="manager-table" class="panel">${render(rows)}</section>`,
    after: () => {
      const filter = () => {
        const q = $("#manager-search").value.toLocaleLowerCase("tr-TR");
        $("#manager-table").innerHTML = render(
          rows.filter(
            (u) =>
              (!$("#manager-pending").checked ||
                (u.active && u.membership_status === "pending")) &&
              `${u.full_name} ${u.email} ${u.site_name || ""} ${u.requested_site}`
                .toLocaleLowerCase("tr-TR")
                .includes(q),
          ),
        );
      };
      $("#manager-search").oninput = filter;
      $("#manager-pending").onchange = filter;
    },
  };
};

pages["platform-audit"] = async () => {
  const rows = await api("/platform/audit");
  const labels = {
    "site.created": "Site oluşturuldu",
    "site.updated": "Site güncellendi",
    "manager.created": "Yönetici oluşturuldu",
    "manager.updated": "Yönetici ataması / onayı değişti",
    "manager.password_reset": "Yönetici geçici şifresi değişti",
    "account.super_admin_granted": "Platform sahibi yetkilendirildi",
    "auth.register": "Yönetici başvurusu",
    "auth.login": "Giriş yapıldı",
  };
  return {
    html:
      heading(
        "Platform işlem geçmişi",
        "Son 300 kayıt: site, kullanıcı ve yetkilendirme işlemleri.",
      ) +
      `<section class="panel">${table(
        ["Tarih", "İşlemi yapan", "Site", "İşlem", "Kayıt", "Ayrıntı"],
        rows.map((r) => [
          e(new Date(r.created_at).toLocaleString("tr-TR")),
          e(r.full_name || "Sistem / başvuru"),
          e(r.site_name || "Platform"),
          e(labels[r.action] || r.action),
          e(r.entity_id || "—"),
          e(JSON.stringify(r.detail)),
        ]),
      )}</section>`,
  };
};

document.addEventListener("click", async (event) => {
  const target = event.target.closest('[data-action^="platform-"]');
  if (!target) return;
  const action = target.dataset.action,
    id = Number(target.dataset.id);
  const save = async (path, method, data) => {
    const result = await api(path, { method, body: data });
    toast(result.message || "Kayıt kaydedildi.");
  };
  try {
    if (["platform-site-new", "platform-site-edit"].includes(action)) {
      const s = platformState.sites.find((s) => s.id === id) || {};
      formModal(
        id ? "Site bilgileri" : "Site ekle",
        field("Site adı", "name", s.name, "text", 'required maxlength="160"') +
          field("Adres", "address", s.address, "text", 'maxlength="500"') +
          (id ? checkbox("Site aktif", "active", s.active) : ""),
        (data) =>
          save("/platform/sites" + (id ? `/${id}` : ""), id ? "PUT" : "POST", {
            ...data,
            active: id ? data.active === "on" : true,
          }),
        "Siteyi pasif yapmak, bu sitedeki tüm hesapların site verilerine erişimini durdurur.",
      );
    } else if (action === "platform-manager-new") {
      formModal(
        "Yönetici ekle",
        field("Ad soyad", "full_name", "", "text", 'required maxlength="120"') +
          field(
            "E-posta",
            "email",
            "",
            "email",
            'required maxlength="254" autocomplete="off"',
          ) +
          field(
            "Geçici şifre",
            "password",
            "",
            "password",
            'required minlength="12" autocomplete="new-password"',
          ),
        (data) => save("/platform/managers", "POST", data),
        "Hesap açıldıktan sonra listeden site bağlayıp onaylayın. Geçici şifreyi yöneticiye iletin; ilk girişte değiştirmesi gerekir. E-posta gönderilmez.",
      );
    } else if (action === "platform-manager-edit") {
      const u = platformState.managers.find((u) => u.id === id);
      formModal(
        "Site bağla ve yetkilendir",
        field(
          "Ad soyad",
          "full_name",
          u.full_name,
          "text",
          'required maxlength="120"',
        ) +
          selectField(
            "Bu yöneticinin sitesi",
            "site_id",
            [
              ["", "Site seçin"],
              ...platformState.sites
                .filter((s) => s.active || s.id === u.site_id)
                .map((s) => [s.id, s.name + (s.active ? "" : " (Pasif)")]),
            ],
            u.site_id || "",
          ) +
          checkbox(
            "Sisteme erişimini onaylıyorum",
            "approved",
            u.membership_status === "approved",
          ) +
          checkbox("Hesap aktif", "active", u.active),
        (data) =>
          save(`/platform/managers/${id}`, "PUT", {
            ...data,
            site_id: data.site_id ? Number(data.site_id) : null,
            approved: data.approved === "on",
            active: data.active === "on",
          }),
        `${u.email} · Onay için aktif bir site seçin. Başvuruyu reddetmek için hesap aktif seçeneğini kaldırın.`,
      );
    } else if (action === "platform-manager-password") {
      formModal(
        "Yönetici geçici şifresi",
        field(
          "Geçici şifre",
          "password",
          "",
          "password",
          'required minlength="12" autocomplete="new-password"',
        ),
        (data) => save(`/platform/managers/${id}/password`, "POST", data),
        "Yönetici ilk girişte kendi şifresini belirler. E-posta gönderilmez.",
      );
    }
  } catch (error) {
    toast(error.message, true);
  }
});
