"use strict";
const paymentStates = {
  pending: "Onay bekliyor",
  approved: "Onaylandı",
  rejected: "Reddedildi",
};
const announcementKinds = {
  general: "Genel",
  maintenance: "Bakım / çalışma",
  meeting: "Toplantı",
  event: "Etkinlik",
  urgent: "Önemli",
};
const visitStates = {
  expected: "Bekleniyor",
  inside: "İçeride",
  departed: "Çıkış yaptı",
  cancelled: "İptal",
};
const dateTime = (value) =>
  value
    ? new Date(value).toLocaleString("tr-TR", {
        dateStyle: "short",
        timeStyle: "short",
      })
    : "—";
const localInput = (value) => {
  const d = new Date(value);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 16);
};

pages.payments = async () => {
  const [rows, apartments] = await Promise.all([
    api("/payments"),
    api("/apartments"),
  ]);
  state.rows = rows;
  state.apartments = apartments;
  const headers = [
    "Makbuz / kayıt",
    "Daire",
    "Ödeme tarihi",
    "Yöntem",
    "Tutar",
    "Durum",
    "İşlemler",
  ];
  const render = (items) =>
    table(
      headers,
      items.map((r) => [
        e(r.receipt_no || `Bildirim #${r.id}`),
        apartmentLabel(r),
        e(dateText(r.paid_on)),
        e(methodNames[r.method]),
        moneyCell(r.amount),
        badge(
          r.voided_at ? "İptal" : paymentStates[r.status],
          r.voided_at || r.status === "rejected"
            ? "red"
            : r.status === "pending"
              ? "amber"
              : "green",
        ) +
          (r.review_note
            ? `<span class="cell-sub">${e(r.review_note)}</span>`
            : ""),
        `<div class="row-actions">${r.status === "approved" ? button("Makbuz", "receipt", `data-id="${r.id}"`, "small", "") : ""}${admin() && r.status === "pending" ? button("Onayla", "payment-review", `data-id="${r.id}" data-decision="approved"`, "small", "") + button("Reddet", "payment-review", `data-id="${r.id}" data-decision="rejected"`, "small danger", "") : ""}${admin() && r.status === "approved" && !r.voided_at ? button("İptal et", "void", `data-id="${r.id}"`, "small danger", "") : ""}</div>`,
      ]),
    );
  return {
    html:
      heading(
        admin() ? "Tahsilat onayları" : "Ödemelerim",
        "Ödeme bildirimi yönetici onayıyla kesinleşir.",
        button(
          admin() ? "Tahsilat kaydı aç" : "Ödeme bildir",
          "new",
          'data-entity="payment"',
        ),
      ) +
      `<div class="info-strip">${rows.filter((r) => r.status === "pending").length} kayıt onay bekliyor. Onaylanmamış kayıtlar borçtan düşmez; kasa, rapor ve makbuza yansımaz.</div><div class="toolbar operation-toolbar"><label>Ödeme ara<input id="payment-search" class="search" aria-label="Ödeme ara"></label><label>Durum<select id="payment-status" aria-label="Ödeme durumu"><option value="">Tüm durumlar</option><option value="pending">Onay bekliyor</option><option value="approved">Onaylandı</option><option value="rejected">Reddedildi</option></select></label></div><section id="payment-table" class="panel">${render(rows)}</section>`,
    after: () => {
      const filter = () => {
        const q = $("#payment-search").value.toLocaleLowerCase("tr-TR");
        $("#payment-table").innerHTML = render(
          rows.filter(
            (r) =>
              (!$("#payment-status").value ||
                r.status === $("#payment-status").value) &&
              `${r.receipt_no || ""} ${r.block} ${r.number} ${r.note}`
                .toLocaleLowerCase("tr-TR")
                .includes(q),
          ),
        );
      };
      $("#payment-search").oninput = filter;
      $("#payment-status").onchange = filter;
    },
  };
};

pages.announcements = async () => {
  const rows = await api("/announcements");
  state.rows = rows;
  const cards = (items) =>
    items.length
      ? `<div class="cards-grid announcement-grid">${items.map((r) => `<article class="content-card announcement-card">${r.image_id ? `<img class="announcement-cover" src="/api/announcement-images/${e(r.image_id)}" alt="${e(r.title)}" loading="lazy">` : `<div class="announcement-cover no-image">${icon("megaphone")}<span>${e(announcementKinds[r.category])}</span></div>`}<div class="announcement-content"><div class="card-top">${badge(announcementKinds[r.category], r.category === "urgent" ? "red" : "green")}${r.pinned ? badge("Sabit", "amber") : ""}</div><h2>${e(r.title)}</h2><p class="announcement-excerpt">${e(r.summary || r.body.slice(0, 220))}</p>${r.event_date ? `<p class="event-line">${icon("clock")}${e(dateText(r.event_date))}${r.location ? " · " + e(r.location) : ""}</p>` : ""}<p class="muted">${e(r.author)} · ${e(dateText(r.created_at))}</p><div class="row-actions">${button("Ayrıntıyı aç", "announcement-detail", `data-id="${r.id}"`, "small", "arrow")}${admin() ? editButton("announcement", r.id) + deleteButton("announcement", r.id) : ""}</div></div></article>`).join("")}</div>`
      : `<section class="panel">${empty("Bu filtreye uygun duyuru bulunmuyor.")}</section>`;
  return {
    html:
      heading(
        "Duyuru panosu",
        "Haberler, planlanan çalışmalar ve ortak yaşam duyuruları.",
        admin()
          ? button("Duyuru yayınla", "new", 'data-entity="announcement"')
          : "",
      ) +
      `<div class="toolbar operation-toolbar"><label>Duyuru ara<input id="announcement-search" class="search" aria-label="Duyuru ara"></label><label>Duyuru türü<select id="announcement-kind" aria-label="Duyuru türü"><option value="">Tüm duyurular</option>${Object.entries(
        announcementKinds,
      )
        .map(([v, l]) => `<option value="${v}">${l}</option>`)
        .join(
          "",
        )}</select></label></div><div id="announcement-cards">${cards(rows)}</div>`,
    after: () => {
      const filter = () => {
        const q = $("#announcement-search").value.toLocaleLowerCase("tr-TR");
        $("#announcement-cards").innerHTML = cards(
          rows.filter(
            (r) =>
              (!$("#announcement-kind").value ||
                r.category === $("#announcement-kind").value) &&
              `${r.title} ${r.body} ${r.summary}`
                .toLocaleLowerCase("tr-TR")
                .includes(q),
          ),
        );
      };
      $("#announcement-search").oninput = filter;
      $("#announcement-kind").onchange = filter;
    },
  };
};

async function uploadAnnouncementImage(file) {
  if (file.size > 5 * 1024 * 1024)
    throw new Error("Görsel en fazla 5 MB olabilir.");
  const form = new FormData();
  form.append("image", file);
  const response = await fetch("/api/announcement-images", {
    method: "POST",
    credentials: "same-origin",
    headers: { "X-CSRF-Token": state.csrf },
    body: form,
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Görsel yüklenemedi.");
  return data.id;
}

function operationForm(entity, r, id, save) {
  if (entity === "payment") {
    const key = crypto.randomUUID();
    formModal(
      admin() ? "Tahsilat kaydı aç" : "Ödeme bildir",
      apartmentSelect(state.user.apartment_id || "") +
        field(
          "Tutar (₺)",
          "amount",
          "",
          "number",
          'required min="0.01" step="0.01"',
        ) +
        field(
          "Ödeme tarihi",
          "paid_on",
          today(),
          "date",
          `required max="${today()}"`,
        ) +
        selectField(
          "Ödeme yöntemi",
          "method",
          Object.entries(methodNames),
          "transfer",
        ) +
        field("Açıklama", "note", "", "text", 'maxlength="500"'),
      async (data) => {
        await save("/payments", { ...data, idempotency_key: key });
        toast("Kayıt alındı. Yönetici onayı bekleniyor.");
      },
      "Bu ekran para transferi veya kart çekimi yapmaz. Kayıt onay bekler; yönetici Tahsilatlar ekranından ayrıca onaylar.",
    );
  } else if (entity === "ledger") {
    const initialKind =
      r.kind ||
      state.categories.find((c) => c.id === r.category_id)?.kind ||
      "expense";
    formModal(
      id ? "Gelir / gider düzenle" : "Gelir / gider ekle",
      selectField(
        "İşlem türü",
        "kind",
        [
          ["expense", "Gider"],
          ["income", "Gelir"],
        ],
        initialKind,
        "required",
      ) +
        selectField("Kategori", "category_id", [], r.category_id) +
        field(
          "Yeni kategori adı",
          "category_name",
          "",
          "text",
          'maxlength="100"',
        ) +
        field(
          "Tutar (₺)",
          "amount",
          r.amount,
          "number",
          'required min="0.01" step="0.01"',
        ) +
        field(
          "Tarih",
          "entry_date",
          r.entry_date || today(),
          "date",
          `required max="${today()}"`,
        ) +
        field(
          "Açıklama",
          "description",
          r.description,
          "text",
          'required maxlength="500"',
        ),
      (data) => save("/ledger" + (id ? "/" + id : ""), data),
      "Önce gelir veya gider türünü seçin. Kategori yoksa yeni kategori adını bu formda yazabilirsiniz.",
    );
    const form = $("#modal-form"),
      kind = $('[name="kind"]', form),
      category = $('[name="category_id"]', form),
      name = $('[name="category_name"]', form);
    const sync = () => {
      const fresh = !category.value;
      name.required = fresh;
      name.disabled = !fresh;
      name.closest("label").hidden = !fresh;
    };
    const populate = (value) => {
      category.innerHTML =
        `<option value="">Yeni kategori oluştur</option>` +
        state.categories
          .filter((c) => c.kind === kind.value)
          .map((c) => `<option value="${c.id}">${e(c.name)}</option>`)
          .join("");
      category.value =
        value || state.categories.find((c) => c.kind === kind.value)?.id || "";
      sync();
    };
    populate(r.category_id);
    kind.onchange = () => populate();
    category.onchange = sync;
  } else if (entity === "announcement") {
    formModal(
      id ? "Duyuruyu düzenle" : "Duyuru yayınla",
      field("Başlık", "title", r.title, "text", 'required maxlength="180"') +
        selectField(
          "Duyuru türü",
          "category",
          Object.entries(announcementKinds),
          r.category || "general",
        ) +
        field("Kısa özet", "summary", r.summary, "text", 'maxlength="280"') +
        field(
          "Etkinlik / çalışma tarihi",
          "event_date",
          r.event_date || "",
          "date",
        ) +
        field(
          "Konum / toplantı yeri",
          "location",
          r.location,
          "text",
          'maxlength="160"',
        ) +
        checkbox("Üste sabitle", "pinned", r.pinned) +
        `<label class="wide">Kapak görseli<input name="image" type="file" accept="image/jpeg,image/png,image/webp"><small>JPEG, PNG veya WebP; en fazla 5 MB.</small></label>` +
        (r.image_id
          ? `<img class="announcement-edit-image" src="/api/announcement-images/${e(r.image_id)}" alt="Mevcut duyuru görseli">${checkbox("Mevcut görseli kaldır", "remove_image")}`
          : "") +
        area("Duyuru ayrıntıları", "body", r.body),
      async (data) => {
        let imageId = r.image_id || null;
        const file = $('#modal-form [name="image"]').files[0];
        if (data.remove_image === "on") imageId = null;
        if (file) imageId = await uploadAnnouncementImage(file);
        const { image, remove_image, ...fields } = data;
        await save("/announcements" + (id ? "/" + id : ""), {
          ...fields,
          pinned: data.pinned === "on",
          image_id: imageId,
        });
      },
      "Kartta kısa özet, ayrıntı penceresinde tüm açıklama ve görsel gösterilir.",
    );
  }
}

pages.guards = async () => {
  const rows = await api("/guards");
  state.rows = rows;
  return {
    html:
      heading(
        "Güvenlik ekibi",
        "Görevliler yalnızca kendi sitelerinin ziyaretçi defteri ve duyurularına erişir.",
        button("Görevli ekle", "guard-new"),
      ) +
      `<section class="panel">${table(
        ["Ad soyad", "E-posta", "Durum", "İşlemler"],
        rows.map((r) => [
          e(r.full_name),
          e(r.email),
          badge(r.active ? "Aktif" : "Pasif", r.active ? "green" : "gray"),
          `<div class="row-actions">${button("Düzenle", "guard-edit", `data-id="${r.id}"`, "small", "")}${button("Geçici şifre", "guard-password", `data-id="${r.id}"`, "small", "")}</div>`,
        ]),
      )}</section>`,
  };
};

pages.visits = async () => {
  const rows = await api("/visits");
  state.rows = rows;
  const gate = admin() || security();
  const render = (items) =>
    table(
      [
        "Ziyaretçi",
        "Daire",
        "Planlanan zaman",
        "Durum",
        "Giriş / çıkış",
        "İşlem",
      ],
      items.map((r) => [
        `<strong>${e(r.guest_name)}</strong><span class="cell-sub">${r.guest_count} kişi${r.vehicle_plate ? " · " + e(r.vehicle_plate) : ""}</span>`,
        apartmentLabel(r),
        `${e(dateTime(r.expected_at))}<span class="cell-sub">${e(dateTime(r.expected_until))} tarihine kadar</span>`,
        badge(
          r.expired ? "Süresi geçti" : visitStates[r.status],
          r.expired
            ? "gray"
            : {
                expected: "amber",
                inside: "green",
                departed: "blue",
                cancelled: "red",
              }[r.status],
        ) +
          `<span class="cell-sub">${r.source === "resident" ? "Sakin ön bildirimi" : "Kapı kaydı"}</span>`,
        `${e(dateTime(r.arrived_at))}<span class="cell-sub">${e(dateTime(r.departed_at))}</span>`,
        `<div class="row-actions">${button("Ayrıntı", "visit-detail", `data-id="${r.id}"`, "small", "")}${gate && r.status === "expected" && !r.expired ? button("Giriş yapıldı", "visit-transition", `data-id="${r.id}" data-step="check_in"`, "small", "") : ""}${gate && r.status === "inside" ? button("Çıkış yapıldı", "visit-transition", `data-id="${r.id}" data-step="check_out"`, "small", "") : ""}${r.status === "expected" && (gate || r.created_by === state.user.id) ? button("İptal", "visit-transition", `data-id="${r.id}" data-step="cancel"`, "small danger", "") : ""}</div>`,
      ]),
    );
  return {
    html:
      heading(
        gate ? "Ziyaretçi defteri" : "Beklediğim ziyaretçiler",
        gate
          ? "Ön bildirimleri kontrol edin; giriş, çıkış ve kapı notlarını kaydedin."
          : "Ziyaretinizi önceden bildirin; güvenlik görevlisi kapıda kaydınızı görsün.",
        button(
          gate ? "Kapıdan ziyaretçi kaydet" : "Ziyaretçi bildir",
          "visit-new",
        ) + button("Yenile", "refresh", "", "", ""),
      ) +
      `<div class="info-strip">${rows.filter((r) => r.status === "inside").length} içeride · ${rows.filter((r) => r.status === "expected" && !r.expired).length} bekleniyor. Ön bildirim giriş kaydı değildir; kapıdaki giriş ve çıkışı güvenlik görevlisi işler. En fazla 500 kayıt gösterilir; arama tüm geçmişte yapılır.</div><div class="toolbar operation-toolbar"><label>Ziyaretçi, plaka veya daire ara<input id="visit-search" class="search" aria-label="Ziyaretçi, plaka veya daire ara"></label><label>Ziyaret durumu<select id="visit-status" aria-label="Ziyaret durumu"><option value="">Tüm durumlar</option>${Object.entries(
        visitStates,
      )
        .map(([v, l]) => `<option value="${v}">${l}</option>`)
        .join(
          "",
        )}</select></label></div><section id="visit-table" class="panel">${render(rows)}</section>`,
    after: () => {
      let timer,
        searchVersion = 0;
      const pageVersion = state.version;
      const filter = async () => {
        if (state.page !== "visits" || state.version !== pageVersion) return;
        const version = ++searchVersion;
        const query = new URLSearchParams({
          q: $("#visit-search").value,
          status: $("#visit-status").value,
        });
        try {
          const items = await api("/visits?" + query);
          if (version !== searchVersion || state.version !== pageVersion)
            return;
          state.rows = items;
          $("#visit-table").innerHTML = render(items);
        } catch (error) {
          if (state.version === pageVersion) toast(error.message, true);
        }
      };
      $("#visit-search").oninput = () => {
        clearTimeout(timer);
        timer = setTimeout(filter, 250);
      };
      $("#visit-status").onchange = () => {
        clearTimeout(timer);
        filter();
      };
    },
  };
};

document.addEventListener("click", async (event) => {
  const target = event.target.closest("[data-action]");
  if (!target) return;
  const action = target.dataset.action,
    id = Number(target.dataset.id),
    r = state.rows.find((r) => r.id === id);
  const save = async (path, data, method = "POST") => {
    const result = await api(path, { method, body: data });
    toast(result.message || "Kayıt kaydedildi.");
  };
  try {
    if (action === "payment-review") {
      const decision = target.dataset.decision;
      formModal(
        decision === "approved" ? "Tahsilatı onayla" : "Ödemeyi reddet",
        field(
          decision === "approved"
            ? "Onay notu (isteğe bağlı)"
            : "Ret gerekçesi",
          "note",
          "",
          "text",
          `${decision === "rejected" ? "required " : ""}maxlength="500"`,
        ),
        (data) => save(`/payments/${id}/review`, { ...data, decision }),
        `${r.block} Blok / ${r.number} · ${money(r.amount)} · ${dateText(r.paid_on)}. ${decision === "approved" ? "Onayla butonuna bastığınızda tutar borçtan düşer, kasaya işlenir ve makbuz oluşur." : "Borç ve kasa değişmez."}`,
        decision === "approved" ? "Onayla" : "Reddet",
      );
    } else if (action === "announcement-detail") {
      openModal(
        r.title,
        `${r.image_id ? `<img class="announcement-detail-image" src="/api/announcement-images/${e(r.image_id)}" alt="${e(r.title)}">` : ""}<div class="detail-meta">${badge(announcementKinds[r.category], r.category === "urgent" ? "red" : "green")}${r.pinned ? badge("Sabit", "amber") : ""}<span>${e(r.author)}</span></div>${r.event_date || r.location ? `<div class="info-strip">${r.event_date ? e(dateText(r.event_date)) : ""}${r.location ? " · " + e(r.location) : ""}</div>` : ""}${r.summary ? `<p class="detail-summary">${e(r.summary)}</p>` : ""}<div class="body-text announcement-body">${e(r.body)}</div><p class="muted">Yayın: ${e(dateTime(r.created_at))} · Güncelleme: ${e(dateTime(r.updated_at))}</p>`,
        true,
      );
    } else if (action === "guard-new" || action === "guard-edit") {
      formModal(
        id ? "Görevliyi düzenle" : "Güvenlik görevlisi ekle",
        field(
          "Ad soyad",
          "full_name",
          r?.full_name,
          "text",
          'required maxlength="120"',
        ) +
          (id
            ? checkbox("Hesap aktif", "active", r.active)
            : field("E-posta", "email", "", "email", "required") +
              field(
                "Geçici şifre",
                "password",
                "",
                "password",
                'required minlength="12" autocomplete="new-password"',
              )),
        (data) =>
          save(
            "/guards" + (id ? "/" + id : ""),
            { ...data, active: data.active === "on" },
            id ? "PUT" : "POST",
          ),
        "Geçici şifre ilk girişte değiştirilir. Görevli mali verilere veya sakin hesaplarına erişemez.",
      );
    } else if (action === "guard-password") {
      formModal(
        "Görevli geçici şifresi",
        field(
          "Geçici şifre",
          "password",
          "",
          "password",
          'required minlength="12" autocomplete="new-password"',
        ),
        (data) => save(`/guards/${id}/password`, data),
      );
    } else if (action === "visit-new") {
      const gate = admin() || security(),
        apartments = await api("/visits/apartments");
      formModal(
        gate ? "Kapıdan gelen ziyaretçi" : "Beklenen ziyaretçi bildir",
        (gate
          ? selectField(
              "Blok",
              "visit_block",
              [["", "Blok seçin"], ...[...new Set(apartments.map((a) => a.block))]
                .sort((a, b) => a.localeCompare(b, "tr", { numeric: true }))
                .map((block) => [block, block + " Blok"])],
              "",
              "required",
            ) + selectField(
              "Ziyaret edilen daire",
              "apartment_id",
              [["", "Önce blok seçin"]],
              "",
              "required disabled",
            )
          : "") +
          field(
            "Ziyaretçi adı soyadı",
            "guest_name",
            "",
            "text",
            'required maxlength="120"',
          ) +
          field(
            "Kişi sayısı",
            "guest_count",
            1,
            "number",
            'required min="1" max="20"',
          ) +
          field(
            "Araç plakası (isteğe bağlı)",
            "vehicle_plate",
            "",
            "text",
            'maxlength="20"',
          ) +
          (!gate
            ? field(
                "Beklenen geliş",
                "expected_at",
                localInput(Date.now()),
                "datetime-local",
                "required",
              ) +
              field(
                "En geç geliş",
                "expected_until",
                localInput(Date.now() + 4 * 3600000),
                "datetime-local",
                "required",
              )
            : "") +
          field(
            "Ziyaret açıklaması",
            "purpose",
            "",
            "text",
            'maxlength="500"',
          ) +
          (gate
            ? field(
                "Kapı notu",
                "security_note",
                "",
                "text",
                'maxlength="1000"',
              )
            : ""),
        (data) => {
          const { visit_block, ...values } = data;
          return save("/visits", {
            ...values,
            ...(!gate
              ? {
                  expected_at: new Date(data.expected_at).toISOString(),
                  expected_until: new Date(data.expected_until).toISOString(),
                }
              : {}),
          });
        },
        gate
          ? "Bu kayıt ziyaretçiyi şu an giriş yapmış olarak kaydeder."
          : "Bildirim yalnızca kendi daireniz içindir. Zaman aralığı güvenlik görevlisine gösterilir; fiili girişi görevli kaydeder.",
      );
      if (gate) {
        const block = $('#modal-form select[name="visit_block"]');
        const apartment = $('#modal-form select[name="apartment_id"]');
        // Blok değişince önceki daire seçimi mutlaka temizlenir.
        block.onchange = () => {
          const options = apartments.filter((a) => a.block === block.value)
            .sort((a, b) => a.number.localeCompare(b.number, "tr", { numeric: true }));
          apartment.innerHTML = `<option value="">${block.value ? "Daire seçin" : "Önce blok seçin"}</option>` +
            options.map((a) => `<option value="${e(a.id)}">Daire ${e(a.number)}</option>`).join("");
          apartment.disabled = !block.value;
          apartment.value = "";
        };
      }
    } else if (action === "visit-transition") {
      const step = target.dataset.step;
      formModal(
        {
          check_in: "Ziyaretçi giriş kaydı",
          check_out: "Ziyaretçi çıkış kaydı",
          cancel: "Ziyareti iptal et",
          note: "Güvenlik notu",
        }[step],
        step === "cancel"
          ? "<p>Bu ziyaret bildirimi iptal edilecek.</p>"
          : field(
              "Güvenlik notu",
              "security_note",
              r.security_note,
              "text",
              'maxlength="1000"',
            ),
        (data) => save(`/visits/${id}/transition`, { ...data, action: step }),
        `${r.guest_name} · ${r.block} / ${r.number}`,
      );
    } else if (action === "visit-detail") {
      openModal(
        r.guest_name,
        `<div class="detail-meta">${badge(visitStates[r.status])}<span>${r.guest_count} kişi</span><span>${e(r.block)} / ${e(r.number)}</span></div><dl class="visit-details"><dt>Bildiren</dt><dd>${e(r.requested_by)}</dd><dt>Beklenen zaman</dt><dd>${e(dateTime(r.expected_at))} — ${e(dateTime(r.expected_until))}</dd><dt>Araç</dt><dd>${e(r.vehicle_plate || "—")}</dd><dt>Açıklama</dt><dd>${e(r.purpose || "—")}</dd><dt>Giriş</dt><dd>${e(dateTime(r.arrived_at))}</dd><dt>Çıkış</dt><dd>${e(dateTime(r.departed_at))}</dd><dt>Güvenlik notu</dt><dd>${e(r.security_note || "—")}</dd></dl>${admin() || security() ? button("Not ekle / düzenle", "visit-transition", `data-id="${id}" data-step="note"`) : ""}`,
      );
    }
  } catch (error) {
    toast(error.message, true);
  }
});
