"use strict";
// Saf JavaScript: tüm veriler aynı sunucudaki REST API'den alınır.
const $ = (selector, root = document) => root.querySelector(selector);
const state = {
  user: null,
  csrf: "",
  page: "dashboard",
  rows: [],
  apartments: [],
  categories: [],
  charts: [],
  version: 0,
};
const escapeHTML = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const e = escapeHTML;
const money = (value) =>
  new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
    maximumFractionDigits: 2,
  }).format(Number(value || 0));
const shortMoney = (value) =>
  new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
    maximumFractionDigits: 0,
  }).format(Number(value || 0));
const dateText = (value) =>
  value
    ? new Date(
        String(value).length === 10 ? value + "T12:00:00" : value,
      ).toLocaleDateString("tr-TR")
    : "—";
const today = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Istanbul",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
const monthNow = () => today().slice(0, 7);
const months = [
  "Ocak",
  "Şubat",
  "Mart",
  "Nisan",
  "Mayıs",
  "Haziran",
  "Temmuz",
  "Ağustos",
  "Eylül",
  "Ekim",
  "Kasım",
  "Aralık",
];
const admin = () => state.user?.role === "admin";
const security = () => state.user?.role === "security";
const superAdmin = () => state.user?.role === "super_admin";
const waiting = () =>
  !superAdmin() &&
  (state.user?.membership_status !== "approved" ||
    !state.user?.site_id ||
    !state.user?.site_active);
const activeNav = () =>
  superAdmin()
    ? platformNav
    : (security()
        ? [
            ["visits", "Ziyaretçi defteri", "users"],
            ["announcements", "Duyurular", "megaphone"],
            ["settings", "Hesabım", "settings"],
          ]
        : navItems
      ).filter(
        (n) =>
          (!n[3] || admin()) &&
          (!waiting() || ["dashboard", "settings"].includes(n[0])),
      );
const methodNames = { cash: "Nakit", transfer: "Havale / EFT", card: "Kart" };
const statusNames = { open: "Açık", progress: "İşlemde", closed: "Kapandı" };
const priorityNames = {
  low: "Düşük",
  normal: "Normal",
  high: "Yüksek",
  urgent: "Acil",
};
const iconPaths = {
  home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M9 21V12h6v9"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  building:
    '<rect x="5" y="2" width="14" height="20" rx="1"/><path d="M9 6h1m4 0h1M9 10h1m4 0h1M9 14h1m4 0h1M10 22v-4h4v4"/>',
  users:
    '<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6m2 3a5 5 0 0 1 3 5v2"/>',
  receipt: '<path d="M5 3h14v19l-3-2-4 2-4-2-3 2zM9 7h6M9 11h6M9 15h3"/>',
  wallet:
    '<path d="M21 8H4a2 2 0 0 1 0-4h14v4M3 6v13a2 2 0 0 0 2 2h16V8M21 12h-6v5h6"/><path d="M17 14.5h1"/>',
  chart: '<path d="M3 3v18h18M7 16v-5m5 5V6m5 10V9"/>',
  megaphone: '<path d="m3 10 17-6v16L3 14zM7 15l2 6h3l-2-5M20 9l3 1v4l-3 1"/>',
  tool: '<path d="M15 4a6 6 0 0 0-7 7L2 17a3 3 0 0 0 4 4l6-6a6 6 0 0 0 8-7l-4 4-4-4z"/>',
  arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  download: '<path d="M12 3v12m-4-4 4 4 4-4M4 16v5h16v-5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  settings:
    '<path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3"/><circle cx="15" cy="17" r="3"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
};
const icon = (name) =>
  `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${iconPaths[name] || iconPaths.grid}</svg>`;
const navItems = [
  ["dashboard", "Genel bakış", "grid"],
  ["apartments", "Daireler", "building"],
  ["residents", "Sakinler", "users"],
  ["charges", "Aidat takibi", "receipt"],
  ["payments", "Tahsilatlar", "wallet"],
  ["ledger", "Gelir & gider", "chart", true],
  ["announcements", "Duyurular", "megaphone"],
  ["tickets", "Arıza & talepler", "tool"],
  ["visits", "Ziyaretçiler", "users"],
  ["guards", "Güvenlik ekibi", "users", true],
  ["reports", "Raporlar", "chart", true],
  ["accounts", "Kullanıcılar", "users", true],
  ["settings", "Hesabım", "settings"],
  ["audit", "İşlem geçmişi", "clock", true],
];

async function api(path, options = {}) {
  const response = await fetch("/api" + path, {
    credentials: "same-origin",
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": state.csrf,
      ...options.headers,
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });
  const data = await response
    .json()
    .catch(() => ({ error: "Sunucudan geçerli yanıt alınamadı." }));
  if (!response.ok) {
    if (response.status === 401 && path !== "/auth/login") showLogin();
    const error = new Error(data.error || "İşlem tamamlanamadı.");
    error.status = response.status;
    throw error;
  }
  return data;
}
async function download(path) {
  const response = await fetch("/api" + path, { credentials: "same-origin" });
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error);
  }
  const url = URL.createObjectURL(await response.blob());
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download =
    response.headers
      .get("Content-Disposition")
      ?.match(/filename="([^"]+)"/)?.[1] || "rapor.csv";
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
let toastTimer;
function toast(message, error = false) {
  clearTimeout(toastTimer);
  $("#toast").textContent = message;
  $("#toast").classList.toggle("error", error);
  $("#toast").hidden = false;
  toastTimer = setTimeout(() => {
    $("#toast").hidden = true;
  }, 5000);
}
function showLogin() {
  state.user = null;
  state.version++;
  closeModal();
  $("#login-view").hidden = false;
  $("#app-view").hidden = true;
  const registration = location.hash === "#register";
  $("#register-form").hidden = !registration;
  $("#login-form").hidden = registration;
  $("#auth-title").textContent = registration
    ? "Yönetici başvurusu."
    : "Hoş geldiniz.";
  $("#auth-subtitle").textContent = registration
    ? "Siteniz için başvurun; platform sahibi kaydınızı değerlendirsin."
    : "E-posta adresiniz ve şifrenizle giriş yapın.";
  $("#login-tab").classList.toggle("active", !registration);
  $("#register-tab").classList.toggle("active", registration);
  document.title = (registration ? "Kayıt" : "Giriş") + " · Avlu";
}
function showApp() {
  $("#login-view").hidden = true;
  $("#app-view").hidden = false;
  $("#navigation").innerHTML = activeNav()
    .map(
      (n) =>
        `<a href="#${n[0]}" data-page="${n[0]}">${icon(n[2])}<span>${e(n[1] === "Sakinler" && !admin() ? "Bilgilerim" : n[1])}</span></a>`,
    )
    .join("");
  $("#profile-name").textContent = state.user.full_name;
  $("#profile-role").textContent = superAdmin()
    ? "Süper admin"
    : security()
      ? "Güvenlik görevlisi"
      : admin()
        ? "Site yöneticisi"
        : "Daire sakini";
  $(".site-chip strong").textContent = superAdmin()
    ? "Platform yönetimi"
    : state.user.site_name || "Site ataması bekleniyor";
  $("#avatar").textContent = state.user.full_name
    .split(" ")
    .map((s) => s[0])
    .slice(0, 2)
    .join("");
  $("#today-label").textContent = new Date().toLocaleDateString("tr-TR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Europe/Istanbul",
  });
  renderRoute();
}
function setMenu(open) {
  $("#sidebar").classList.toggle("open", open);
  $("#sidebar-backdrop").hidden = !open;
  $("#menu-toggle").setAttribute("aria-expanded", String(open));
}
const button = (label, action, params = "", type = "primary", glyph = "plus") =>
  `<button class="button ${type}" data-action="${action}" ${params}>${glyph ? icon(glyph) : ""}${e(label)}</button>`;
const editButton = (entity, id, label = "Düzenle") =>
  `<button class="button small" data-action="edit" data-entity="${entity}" data-id="${id}">${e(label)}</button>`;
const deleteButton = (entity, id) =>
  `<button class="button small danger" data-action="delete" data-entity="${entity}" data-id="${id}">Sil</button>`;
function heading(title, subtitle, actions = "") {
  return `<div class="page-heading"><div><h1>${e(title)}</h1><p>${e(subtitle)}</p></div><div class="heading-actions">${actions}</div></div>`;
}
function badge(label, color = "gray") {
  return `<span class="badge ${color}">${e(label)}</span>`;
}
function empty(label = "Henüz kayıt bulunmuyor.") {
  return `<div class="empty">${icon("home")}${e(label)}</div>`;
}
function table(headers, rows) {
  if (!rows.length)
    return empty(
      "Gösterilecek kayıt yok. Filtrelerinizi kontrol edebilir veya yeni kayıt ekleyebilirsiniz.",
    );
  return `<div class="table-scroll"><table><thead><tr>${headers.map((h) => `<th>${e(h)}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((cell) => `<td>${cell}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}
function stat(label, value, foot, glyph, highlight = false) {
  return `<div class="stat ${highlight ? "highlight" : ""}"><div class="stat-top"><span>${e(label)}</span><span class="stat-icon">${icon(glyph)}</span></div><div class="stat-value" title="${e(value)}">${e(value)}</div><div class="stat-foot">${e(foot)}</div></div>`;
}
function moneyCell(value, cls = "") {
  return `<div class="number ${cls}">${e(money(value))}</div>`;
}
function apartmentLabel(row) {
  return `<strong>${e(row.block)} Blok · ${e(row.number)}</strong>`;
}
function balanceCell(value) {
  return `<span class="${Number(value) > 0 ? "debt" : "credit"}">${e(money(Math.abs(Number(value))))}</span><span class="cell-sub">${Number(value) > 0 ? "Borç" : Number(value) < 0 ? "Alacak" : "Hesap kapalı"}</span>`;
}
function destroyCharts() {
  state.charts.forEach((c) => c.destroy());
  state.charts = [];
}
function drawChart(id, config) {
  const canvas = document.getElementById(id);
  if (!canvas) return;
  if (!window.Chart) {
    canvas.parentElement.innerHTML =
      '<p class="chart-fallback">Grafik kütüphanesi yüklenemedi. İnternet bağlantınızı kontrol edin. Sayısal değerler tablolarda görüntülenebilir.</p>';
    return;
  }
  state.charts.push(new Chart(canvas, config));
}
const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
    tooltip: {
      callbacks: { label: (c) => `${c.dataset.label}: ${money(c.raw)}` },
    },
  },
  scales: {
    x: {
      grid: { display: false },
      border: { display: false },
      ticks: { color: "#99a292", font: { size: 10 } },
    },
    y: {
      beginAtZero: true,
      border: { display: false },
      grid: { color: "#f0f2eb" },
      ticks: {
        color: "#99a292",
        font: { size: 10 },
        callback: (v) => (v >= 1000 ? v / 1000 + " bin" : v),
      },
    },
  },
};

async function renderRoute() {
  if (!state.user) return;
  const defaultPage = superAdmin()
    ? "superadmin"
    : security()
      ? "visits"
      : "dashboard";
  const requested = location.hash.slice(1) || defaultPage;
  state.page = state.user.must_change_password
    ? "settings"
    : waiting()
      ? requested === "settings"
        ? "settings"
        : "dashboard"
      : activeNav().some((n) => n[0] === requested)
        ? requested
        : defaultPage;
  if (location.hash !== "#" + state.page)
    history.replaceState(null, "", "#" + state.page);
  setMenu(false);
  closeModal();
  destroyCharts();
  const version = ++state.version;
  const page = state.page;
  document.querySelectorAll("#navigation a").forEach((a) => {
    a.classList.toggle("active", a.dataset.page === page);
    if (a.dataset.page === page) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  });
  $("#breadcrumb").textContent =
    activeNav().find((n) => n[0] === page)?.[1] || "";
  document.title = `${$("#breadcrumb").textContent} · Avlu`;
  $("#content").innerHTML = '<div class="loading">Veriler yükleniyor…</div>';
  try {
    const render = await pages[page]();
    if (version !== state.version) return;
    $("#content").innerHTML = render.html;
    render.after?.();
  } catch (error) {
    if (version !== state.version) return;
    $("#content").innerHTML =
      `<div class="error-state"><h2>Bu ekran yüklenemedi.</h2><p>${e(error.message)}</p>${button("Tekrar dene", "refresh", "", "", "")}</div>`;
  }
}
const pages = {};
pages.dashboard = async () => {
  if (waiting()) {
    return {
      html:
        heading(
          "Hesap durumu",
          "Hesabınızın siteye erişimi henüz açık değil.",
        ) +
        `<section class="panel settings-panel"><h2>Hoş geldiniz, ${e(state.user.full_name)}.</h2><p class="form-hint">${e(state.user.email)} adresine ait hesabınız için ${admin() ? "platform sahibinin site ataması ve onayı" : "site yöneticinizin daire ataması"} gerekir. Bağlı site kapalıysa yeniden aktif edilmesini bekleyin.</p><div class="actions">${button("Durumu yenile", "refresh-membership", "", "primary", "check")}<a class="button" href="#settings">Profilimi düzenle</a></div></section>`,
    };
  }
  const [data, announcements, tickets, apartments] = await Promise.all([
    api("/dashboard"),
    api("/announcements"),
    api("/tickets"),
    api("/apartments"),
  ]);
  state.apartments = apartments;
  const first = state.user.full_name.split(" ")[0];
  const statHTML = admin()
    ? stat("Toplam daire", data.apartments, "Aktif daireler", "building") +
      stat(
        "Toplam borç",
        shortMoney(data.debt),
        `${shortMoney(data.overdue)} gecikmiş bakiye`,
        "receipt",
      ) +
      stat(
        "Bu ayki tahsilat",
        shortMoney(data.monthly_collections),
        "İptal edilen ödemeler hariç",
        "wallet",
      ) +
      stat(
        "Kasa bakiyesi",
        shortMoney(data.cash),
        "Tüm tahsilat ve kasa hareketleri",
        "chart",
        true,
      )
    : stat(
        "Dairem",
        apartments.length
          ? `${apartments[0].block} / ${apartments[0].number}`
          : "—",
        "Bağlı olduğunuz daire",
        "building",
      ) +
      stat(
        "Güncel borcum",
        shortMoney(data.debt),
        `${shortMoney(data.overdue)} gecikmiş bakiye`,
        "receipt",
      ) +
      stat(
        "Bu ay ödemelerim",
        shortMoney(data.monthly_collections),
        `${shortMoney(data.credit)} alacak bakiyesi`,
        "wallet",
      ) +
      stat(
        "Açık taleplerim",
        data.open_tickets,
        "Yönetimin değerlendirmesinde",
        "tool",
        true,
      );
  const recent = admin()
    ? apartments
        .filter((a) => Number(a.balance) > 0)
        .sort((a, b) => Number(b.overdue) - Number(a.overdue))
        .slice(0, 5)
    : apartments;
  const quick = admin()
    ? [
        ["Tahsilat ekle", "new", 'data-entity="payment"', "wallet"],
        ["Aidat oluştur", "new", 'data-entity="batch"', "receipt"],
        ["Gider kaydet", "new", 'data-entity="ledger"', "chart"],
        ["Duyuru yayınla", "new", 'data-entity="announcement"', "megaphone"],
      ]
    : [
        [
          "Hesap ekstrem",
          "statement",
          `data-id="${state.user.apartment_id || 0}"`,
          "receipt",
        ],
        ["Talep oluştur", "new", 'data-entity="ticket"', "tool"],
      ];
  return {
    html:
      heading(
        "Genel bakış",
        "Yaşam alanınızın güncel durumu, bir bakışta.",
        admin()
          ? button("Tahsilat ekle", "new", 'data-entity="payment"')
          : button("Talep oluştur", "new", 'data-entity="ticket"'),
      ) +
      `<section class="welcome-banner"><div><span class="eyebrow">${e(new Date().toLocaleDateString("tr-TR", { month: "long", year: "numeric" }).toLocaleUpperCase("tr-TR"))} · YÖNETİM ÖZETİ</span><h2>Merhaba ${e(first)}, avluya hoş geldiniz.</h2><p>${data.open_tickets} açık talep var. ${admin() ? "Sitenizin günlük işlerini buradan takip edebilirsiniz." : "Dairenize ait ödeme ve taleplere buradan ulaşabilirsiniz."}</p></div><div class="banner-illustration" aria-hidden="true"><span></span><span></span><span></span></div></section>` +
      `<div class="stat-grid">${statHTML}</div><div class="dashboard-grid"><section class="panel"><div class="panel-heading"><div><h2>${admin() ? "Gelir & gider dengesi" : "Aylık aidatlarım"}</h2><p>${admin() ? "Yıl boyunca nakit akışınız" : "Dairenize tanımlanan son 12 dönem"}</p></div><div class="legend"><span>${admin() ? "Gelir" : "Aidat"}</span>${admin() ? "<span>Gider</span>" : ""}</div></div><div class="panel-content"><div class="chart-wrap"><canvas id="dashboard-chart" aria-label="Aylık tutarlar grafiği" role="img"></canvas></div><div class="chart-note">${admin() ? "Aidat tahsilatları toplam gelire dahildir. Ayrıntılar Raporlar ekranındadır." : "Aidat ayrıntıları ve kalan borçlar Aidat takibi ekranındadır."}</div></div></section><section class="panel"><div class="panel-heading"><h2>Hızlı işlemler</h2><span class="muted">↗</span></div><div class="panel-content"><div class="quick-grid">${quick.map((q) => `<button class="quick-action" data-action="${q[1]}" ${q[2]}>${icon(q[3])}<span>${e(q[0])}</span></button>`).join("")}</div><div class="notice-mini"><h3>Her işlem kayıt altında.</h3><p>${admin() ? "Tahsilatları makbuzuyla, giderleri kategorisiyle takip edin." : "Ödeme geçmişinizi inceleyin, makbuzlarınızı yazdırın."}</p></div></div></section></div>` +
      `<div class="dashboard-grid"><section class="panel"><div class="panel-heading"><div><h2>${admin() ? "Ödeme bekleyen daireler" : "Daire hesabım"}</h2><p>${admin() ? "Gecikmiş bakiyeye göre sıralandı" : "Güncel borç ve alacak durumu"}</p></div><a class="button ghost small" href="#${admin() ? "reports" : "charges"}">Tümünü gör →</a></div>${table(
        ["Daire", "Sakin", "Bakiye", ""],
        recent.map((a) => [
          apartmentLabel(a),
          e(a.residents) || "—",
          balanceCell(a.balance),
          `<button class="button small" data-action="statement" data-id="${a.id}">Ekstre ↗</button>`,
        ]),
      )}</section><section class="panel"><div class="panel-heading"><h2>Duyuru panosu</h2><a class="button ghost small" href="#announcements">Tümü →</a></div><div class="panel-content">${
        announcements
          .slice(0, 2)
          .map(
            (a) =>
              `<article class="notice-mini"><h3>${e(a.title)}</h3><p>${e(a.body.slice(0, 140))}${a.body.length > 140 ? "…" : ""}</p><small>${e(dateText(a.created_at))}</small></article>`,
          )
          .join("") || empty("Yeni duyuru bulunmuyor.")
      }</div></section></div>`,
    after: () =>
      drawChart("dashboard-chart", {
        type: "bar",
        data: {
          labels: data.chart.map((r) =>
            admin() ? months[r.month - 1].slice(0, 3) : r.period,
          ),
          datasets: admin()
            ? [
                {
                  label: "Gelir",
                  data: data.chart.map((r) => Number(r.income)),
                  backgroundColor: "#3b6650",
                  borderRadius: 4,
                  barPercentage: 0.7,
                },
                {
                  label: "Gider",
                  data: data.chart.map((r) => Number(r.expense)),
                  backgroundColor: "#d8c8a7",
                  borderRadius: 4,
                  barPercentage: 0.7,
                },
              ]
            : [
                {
                  label: "Aidat",
                  data: data.chart.map((r) => Number(r.amount)),
                  backgroundColor: "#3b6650",
                  borderRadius: 4,
                },
              ],
        },
        options: chartOptions,
      }),
  };
};

function searchable(title, subtitle, entity, rows, headers, rowRenderer) {
  state.rows = rows;
  return {
    html:
      heading(
        title,
        subtitle,
        admin()
          ? button(
              "Yeni " +
                ({ apartment: "daire", resident: "sakin" }[entity] || "kayıt"),
              "new",
              `data-entity="${entity}"`,
            )
          : "",
      ) +
      `<div class="toolbar"><input class="search" id="search-input" aria-label="Kayıtlarda ara"><span class="record-count" id="record-count">${rows.length} kayıt</span></div><section class="panel" id="list-table">${table(headers, rows.map(rowRenderer))}</section>`,
    after: () => {
      $("#search-input").addEventListener("input", (event) => {
        const q = event.target.value.toLocaleLowerCase("tr-TR");
        const filtered = rows.filter((r) =>
          Object.values(r).some((v) =>
            String(v ?? "")
              .toLocaleLowerCase("tr-TR")
              .includes(q),
          ),
        );
        $("#list-table").innerHTML = table(headers, filtered.map(rowRenderer));
        $("#record-count").textContent = filtered.length + " kayıt";
      });
    },
  };
}
pages.apartments = async () => {
  const rows = await api("/apartments");
  state.apartments = rows;
  return searchable(
    "Daireler",
    "Daire bilgileri, sakinler ve güncel hesap durumu.",
    "apartment",
    rows,
    [
      "Daire",
      "Kat / Alan",
      "Arsa payı",
      "Sakinler",
      "Bakiye",
      "Durum",
      "İşlemler",
    ],
    (r) => [
      apartmentLabel(r),
      `${r.floor}. kat<span class="cell-sub">${e(r.area)} m²</span>`,
      e(r.land_share),
      e(r.residents) || "—",
      balanceCell(r.balance),
      badge(r.active ? "Aktif" : "Pasif", r.active ? "green" : "gray"),
      `<div class="row-actions"><button class="button small" data-action="statement" data-id="${r.id}">Ekstre</button>${admin() ? editButton("apartment", r.id) + deleteButton("apartment", r.id) : ""}</div>`,
    ],
  );
};
pages.residents = async () => {
  const [rows, apartments] = await Promise.all([
    api("/residents"),
    api("/apartments"),
  ]);
  state.apartments = apartments;
  return searchable(
    admin() ? "Sakinler" : "Bilgilerim",
    "Ev sahibi ve kiracı kayıtları, iletişim ve giriş bilgileri.",
    "resident",
    rows,
    [
      "Ad soyad",
      "Daire",
      "İletişim",
      "Tür",
      "Giriş / Çıkış",
      "Hesap",
      "İşlemler",
    ],
    (r) => [
      `<strong>${e(r.full_name)}</strong>`,
      apartmentLabel(r),
      `${e(r.email)}<span class="cell-sub">${e(r.phone) || "Telefon yok"}</span>`,
      badge(
        r.occupancy === "owner" ? "Ev sahibi" : "Kiracı",
        r.occupancy === "owner" ? "green" : "blue",
      ),
      `${e(dateText(r.move_in))}<span class="cell-sub">${r.move_out ? "Çıkış: " + e(dateText(r.move_out)) : "Oturum devam ediyor"}</span>`,
      badge(r.active ? "Aktif" : "Kapalı", r.active ? "green" : "gray"),
      admin()
        ? `<div class="row-actions">${editButton("resident", r.id)}${editButton("reset", r.id, "Şifre")}${deleteButton("resident", r.id)}</div>`
        : "Yönetici güncelleyebilir",
    ],
  );
};
pages.charges = async () => {
  const [rows, apartments] = await Promise.all([
    api("/charges"),
    api("/apartments"),
  ]);
  state.rows = rows;
  state.apartments = apartments;
  function chargeRows(items) {
    return items.map((r) => [
      apartmentLabel(r),
      e(r.period.slice(0, 7)),
      e(r.description),
      e(dateText(r.due_date)),
      moneyCell(r.amount),
      moneyCell(r.outstanding, Number(r.outstanding) > 0 ? "debt" : "credit"),
      Number(r.outstanding) <= 0
        ? badge("Ödendi", "green")
        : badge(
            r.due_date < today() ? "Gecikmiş" : "Bekliyor",
            r.due_date < today() ? "red" : "amber",
          ),
      admin()
        ? `<div class="row-actions">${editButton("charge", r.id)}${deleteButton("charge", r.id)}</div>`
        : "",
    ]);
  }
  const headers = [
    "Daire",
    "Dönem",
    "Açıklama",
    "Son ödeme",
    "Aidat",
    "Kalan",
    "Durum",
    "İşlemler",
  ];
  return {
    html:
      heading(
        "Aidat takibi",
        "Aylık aidatları ve dairelerin ödeme durumunu takip edin.",
        admin()
          ? button("Toplu aidat oluştur", "new", 'data-entity="batch"')
          : "",
      ) +
      '<div class="info-strip">Ödemeler en eski vadeli aidattan başlayarak mahsup edilir. Fazla ödemeler dairenin alacak bakiyesinde tutulur.</div>' +
      `<div class="toolbar"><div class="filters"><input class="filter-select" id="charge-month" type="month" aria-label="Aidat dönemi"><select class="filter-select" id="charge-status" aria-label="Ödeme durumu"><option value="">Tüm durumlar</option value="overdue">Gecikmiş</option><option value="pending">Ödeme bekleyen</option><option value="paid">Ödenmiş</option></select><button class="button" data-action="clear-charges">Filtreyi temizle</button></div><span class="record-count">${rows.length} aidat kaydı</span></div><section class="panel" id="charge-table">${table(headers, chargeRows(rows))}</section>`,
    after: () => {
      const filter = () => {
        const month = $("#charge-month").value,
          status = $("#charge-status").value;
        const filtered = rows.filter(
          (r) =>
            (!month || r.period.startsWith(month)) &&
            (!status ||
              (status === "paid"
                ? Number(r.outstanding) <= 0
                : status === "overdue"
                  ? Number(r.outstanding) > 0 && r.due_date < today()
                  : Number(r.outstanding) > 0)),
        );
        $("#charge-table").innerHTML = table(headers, chargeRows(filtered));
      };
      $("#charge-month").onchange = filter;
      $("#charge-status").onchange = filter;
    },
  };
};
pages.ledger = async () => {
  const [rows, categories] = await Promise.all([
    api("/ledger"),
    api("/categories"),
  ]);
  state.rows = rows;
  state.categories = categories;
  const rowRenderer = (r) => [
    e(dateText(r.entry_date)),
    badge(
      r.kind === "income" ? "Gelir" : "Gider",
      r.kind === "income" ? "green" : "red",
    ),
    e(r.category),
    e(r.description),
    moneyCell(r.amount, r.kind === "income" ? "credit" : ""),
    `<div class="row-actions">${editButton("ledger", r.id)}${deleteButton("ledger", r.id)}</div>`,
  ];
  const headers = ["Tarih", "Tür", "Kategori", "Açıklama", "Tutar", "İşlemler"];
  return {
    html:
      heading(
        "Gelir & gider",
        "Ortak alan giderleri ve aidat dışındaki gelirler.",
        button("Kategoriler", "categories", "", "", "settings") +
          button("Hareket ekle", "new", 'data-entity="ledger"'),
      ) +
      '<div class="info-strip">Yönetici onaylı aidat tahsilatları kasaya yansır; buradan yeniden gelir olarak eklemeyin. Kasa bakiyesi tüm nakit, banka ve kart hareketlerinin toplamıdır.</div>' +
      `<div class="toolbar"><div class="filters"><input type="month" class="filter-select" id="ledger-month" aria-label="Ay filtresi"><select class="filter-select" id="ledger-kind" aria-label="Hareket türü"><option value="">Gelir ve gider</option value="income">Gelir</option><option value="expense">Gider</option></select><button class="button" data-action="clear-ledger">Filtreyi temizle</button></div><span class="record-count">${rows.length} kayıt</span></div><section class="panel" id="ledger-table">${table(headers, rows.map(rowRenderer))}</section>`,
    after: () => {
      const filter = () => {
        $("#ledger-table").innerHTML = table(
          headers,
          rows
            .filter(
              (r) =>
                (!$("#ledger-month").value ||
                  r.entry_date.startsWith($("#ledger-month").value)) &&
                (!$("#ledger-kind").value ||
                  r.kind === $("#ledger-kind").value),
            )
            .map(rowRenderer),
        );
      };
      $("#ledger-month").onchange = filter;
      $("#ledger-kind").onchange = filter;
    },
  };
};
pages.tickets = async () => {
  const rows = await api("/tickets");
  state.rows = rows;
  const cards = (items) =>
    items.length
      ? `<div class="cards-grid">${items.map((r) => `<article class="content-card"><div class="card-top"><div class="actions">${badge(statusNames[r.status], { open: "amber", progress: "blue", closed: "green" }[r.status])}${badge(priorityNames[r.priority], ["high", "urgent"].includes(r.priority) ? "red" : "gray")}</div><small class="muted">#${r.id}</small></div><h2>${e(r.title)}</h2><div class="body-text">${e(r.description)}</div>${r.response ? `<div class="response"><strong>Yönetimin yanıtı</strong>${e(r.response)}</div>` : ""}<div class="card-meta"><span>${e(r.full_name)}${r.block ? " · " + e(r.block) + " / " + e(r.number) : ""}<span class="cell-sub">${e(dateText(r.created_at))}</span></span>${admin() ? editButton("ticket", r.id, "Talebi yönet") : ""}</div></article>`).join("")}</div>`
      : `<section class="panel">${empty("Bu durumda talep bulunmuyor.")}</section>`;
  return {
    html:
      heading(
        "Arıza & talepler",
        "Ortak yaşamla ilgili ihtiyaçlarınızı buradan takip edin.",
        button("Yeni talep", "new", 'data-entity="ticket"'),
      ) +
      `<div class="toolbar"><select class="filter-select" id="ticket-status" aria-label="Talep durumu"><option value="">Tüm talepler (${rows.length})</option value="open">Açık</option><option value="progress">İşlemde</option><option value="closed">Kapandı</option></select></div><div id="ticket-cards">${cards(rows)}</div>`,
    after: () => {
      $("#ticket-status").onchange = (event) => {
        $("#ticket-cards").innerHTML = cards(
          rows.filter(
            (r) => !event.target.value || r.status === event.target.value,
          ),
        );
      };
    },
  };
};
pages.reports = async () => {
  const [report, debtors] = await Promise.all([
    api("/reports/financial?year=" + today().slice(0, 4)),
    api("/reports/debtors"),
  ]);
  const totals = (report) =>
    stat(
      "Toplam gelir",
      shortMoney(report.totals.income),
      "Aidat tahsilatları dahil",
      "wallet",
    ) +
    stat(
      "Toplam gider",
      shortMoney(report.totals.expense),
      "Seçilen dönemdeki giderler",
      "chart",
    ) +
    stat(
      "Dönem neti",
      shortMoney(report.totals.net),
      "Gelir eksi gider",
      "receipt",
      true,
    );
  const financialTable = (report) =>
    table(
      ["Ay", "Aidat tahsilatı", "Diğer gelir", "Toplam gelir", "Gider", "Net"],
      report.rows.map((r) => [
        months[r.month - 1],
        moneyCell(r.collections),
        moneyCell(r.other_income),
        moneyCell(r.income),
        moneyCell(r.expense),
        moneyCell(r.net, Number(r.net) < 0 ? "debt" : "credit"),
      ]),
    );
  const debtTable = (items) =>
    table(
      ["Daire", "Sakinler", "Aidat toplamı", "Tahsilat", "Borç", "Geciken", ""],
      items.map((r) => [
        apartmentLabel(r),
        e(r.residents) || "—",
        moneyCell(r.charged),
        moneyCell(r.paid),
        moneyCell(r.balance, "debt"),
        moneyCell(r.overdue, "debt"),
        `<button class="button small" data-action="statement" data-id="${r.id}">Ekstre</button>`,
      ]),
    );
  return {
    html:
      heading(
        "Raporlar",
        "Dönem sonuçlarını inceleyin, Excel uyumlu CSV olarak dışa aktarın.",
      ) +
      `<div class="toolbar"><div class="filters"><label>Yıl<input id="report-year" class="filter-select" type="number" min="2000" max="2100" value="${report.year}"></label><label>Dönem<select id="report-month" class="filter-select"><option value="">Tüm yıl</option>${months.map((m, i) => `<option value="${i + 1}">${m}</option>`).join("")}</select></label>${button("Raporu getir", "report-filter", "", "", "chart")}</div>${button("Gelir-gider CSV", "download-financial", "", "", "download")}</div><div class="stat-grid report-totals" id="report-totals">${totals(report)}</div><section class="panel"><div class="panel-heading"><h2>Aylık gelir-gider dökümü</h2></div><div id="financial-table">${financialTable(report)}</div></section>` +
      `<section class="panel report-totals"><div class="panel-heading"><div><h2>Borçlu daireler</h2><p>Dönem filtresinden bağımsız, güncel tüm borçlar.</p></div><div class="actions"><label class="checkbox"><input type="checkbox" id="only-overdue"> Yalnız gecikenler</label>${button("Borçlu listesi CSV", "download-debtors", "", "", "download")}</div></div><div id="debt-table">${debtTable(debtors)}</div></section>`,
    after: () => {
      $("#only-overdue").onchange = () => {
        $("#debt-table").innerHTML = debtTable(
          debtors.filter(
            (r) => !$("#only-overdue").checked || Number(r.overdue) > 0,
          ),
        );
      };
      document.querySelector('[data-action="report-filter"]').onclick = async (
        event,
      ) => {
        event.stopPropagation();
        const b = event.currentTarget;
        b.disabled = true;
        try {
          const data = await api("/reports/financial?" + reportQuery());
          $("#financial-table").innerHTML = financialTable(data);
          $("#report-totals").innerHTML = totals(data);
        } catch (err) {
          toast(err.message, true);
        } finally {
          b.disabled = false;
        }
      };
    },
  };
};
function reportQuery() {
  return new URLSearchParams({
    year: $("#report-year").value,
    month: $("#report-month").value,
  }).toString();
}
pages.settings = async () => ({
  html:
    heading(
      "Hesabım",
      "Hesap bilgilerinizi görüntüleyin ve şifrenizi güncelleyin.",
    ) +
    (state.user.must_change_password
      ? '<div class="info-strip">İlk girişinizde geçici şifrenizi değiştirmeniz gerekiyor. Şifre değişikliğinden sonra tüm ekranlar açılacaktır.</div>'
      : "") +
    `<section class="panel settings-panel profile-panel"><h2>Profil bilgileri</h2><form id="profile-form"><label>Ad soyad<input name="full_name" value="${e(state.user.full_name)}" maxlength="120" required></label><p class="form-error" role="alert"></p><div class="form-actions"><button class="button primary" type="submit">Profili kaydet</button></div></form></section>` +
    `<section class="panel settings-panel"><h2>${e(state.user.full_name)}</h2><p class="muted">${e(state.user.email)} · ${superAdmin() ? "Süper admin" : security() ? "Güvenlik görevlisi" : admin() ? "Yönetici" : "Daire sakini"}</p><form id="password-form"><div class="form-grid"><label class="wide">Mevcut şifre<input name="current_password" type="password" autocomplete="current-password" required></label><label>Yeni şifre<input name="new_password" type="password" autocomplete="new-password" minlength="12" required></label><label>Yeni şifre tekrar<input name="confirm_password" type="password" autocomplete="new-password" minlength="12" required></label></div><p class="form-hint">En az 12 karakter kullanın. Şifre en fazla 72 UTF-8 bayt olabilir.</p><p class="form-error" role="alert"></p><button class="button primary" type="submit">Şifreyi güncelle</button></form></section>`,
  after: () => {
    $("#profile-form").onsubmit = async (event) => {
      event.preventDefault();
      const form = event.target,
        submit = $("button", form);
      submit.disabled = true;
      try {
        await api("/auth/profile", {
          method: "PUT",
          body: Object.fromEntries(new FormData(form)),
        });
        state.user = await api("/auth/me");
        toast("Profiliniz güncellendi.");
        showApp();
      } catch (error) {
        $(".form-error", form).textContent = error.message;
      } finally {
        submit.disabled = false;
      }
    };
    $("#password-form").onsubmit = async (event) => {
      event.preventDefault();
      const form = event.target,
        data = Object.fromEntries(new FormData(form));
      if (data.new_password !== data.confirm_password) {
        $(".form-error", form).textContent = "Yeni şifreler eşleşmiyor.";
        return;
      }
      const b = $("button", form);
      b.disabled = true;
      try {
        await api("/auth/password", { method: "POST", body: data });
        state.user = await api("/auth/me");
        toast("Şifreniz güncellendi.");
        location.hash = "dashboard";
        showApp();
      } catch (error) {
        $(".form-error", form).textContent = error.message;
      } finally {
        b.disabled = false;
      }
    };
  },
});
pages.accounts = async () => {
  const rows = await api("/accounts");
  state.rows = rows;
  const columns = [
    "Kullanıcı",
    "E-posta",
    "Rol",
    "Üyelik",
    "Daire",
    "İşlemler",
  ];
  const renderer = (r) => [
    `<strong>${e(r.full_name)}</strong><span class="cell-sub">${dateText(r.created_at)}</span>`,
    e(r.email),
    badge(
      r.role === "admin" ? "Yönetici" : "Sakin",
      r.role === "admin" ? "blue" : "gray",
    ),
    badge(
      !r.active
        ? "Kapalı"
        : r.membership_status === "approved"
          ? "Onaylı"
          : "Onay bekliyor",
      !r.active
        ? "red"
        : r.membership_status === "approved"
          ? "green"
          : "amber",
    ),
    r.apartment_id ? apartmentLabel(r) : "Daire eşleşmesi yok",
    `<div class="row-actions"><button class="button small" data-action="account-edit" data-id="${r.id}">Yetkiler</button><button class="button small" data-action="account-password" data-id="${r.id}">Şifre</button>${!r.apartment_id && r.role === "resident" ? `<button class="button small" data-action="account-link" data-id="${r.id}">Daireye bağla</button>` : ""}</div>`,
  ];
  return {
    html:
      heading(
        "Kullanıcılar",
        "Kayıtları onaylayın, daireye bağlayın ve hesap yetkilerini yönetin.",
      ) +
      `<div class="info-strip">Sakinleri Sakinler ekranından e-posta, geçici şifre ve daire bilgileriyle ekleyin. Buradan yalnızca kendi sitenizin sakin hesaplarını yönetebilirsiniz.</div><div class="toolbar"><input id="account-search" class="search" aria-label="Kullanıcı ara"><span class="record-count">${rows.length} hesap</span></div><section id="account-table" class="panel">${table(columns, rows.map(renderer))}</section>`,
    after: () => {
      $("#account-search").oninput = (event) => {
        const q = event.target.value.toLocaleLowerCase("tr-TR");
        $("#account-table").innerHTML = table(
          columns,
          rows
            .filter((r) =>
              (r.full_name + " " + r.email)
                .toLocaleLowerCase("tr-TR")
                .includes(q),
            )
            .map(renderer),
        );
      };
    },
  };
};

pages.audit = async () => {
  const rows = await api("/audit");
  const actionNames = {
    "auth.register": "Kullanıcı kaydı alındı",
    "auth.login": "Oturum açıldı",
    "auth.login_failed": "Başarısız giriş denemesi",
    "auth.logout": "Oturum kapatıldı",
    "auth.password_changed": "Şifre değiştirildi",
    "auth.profile_updated": "Profil güncellendi",
    "account.updated": "Hesap yetkileri güncellendi",
    "account.password_reset": "Geçici şifre belirlendi",
    "account.bootstrap": "İlk yönetici oluşturuldu",
    "apartment.create": "Daire eklendi",
    "apartment.update": "Daire güncellendi",
    "apartment.delete": "Daire silindi",
    "resident.create": "Sakin eklendi",
    "resident.update": "Sakin güncellendi",
    "resident.delete": "Sakin silindi",
    "resident.password_reset": "Sakin şifresi sıfırlandı",
    "charges.batch": "Toplu aidat oluşturuldu",
    "charge.update": "Aidat güncellendi",
    "charge.delete": "Aidat silindi",
    "payment.create": "Ödeme bildirimi oluşturuldu",
    "payment.review": "Ödeme değerlendirildi",
    "announcement.image_uploaded": "Duyuru görseli yüklendi",
    "guard.created": "Güvenlik görevlisi eklendi",
    "guard.updated": "Güvenlik hesabı güncellendi",
    "guard.password_reset": "Güvenlik geçici şifresi değişti",
    "visit.created": "Ziyaretçi kaydı oluşturuldu",
    "visit.check_in": "Ziyaretçi giriş yaptı",
    "visit.check_out": "Ziyaretçi çıkış yaptı",
    "visit.cancel": "Ziyaret iptal edildi",
    "visit.note": "Güvenlik notu güncellendi",
    "payment.void": "Tahsilat iptal edildi",
    "category.create": "Kategori eklendi",
    "category.update": "Kategori güncellendi",
    "category.delete": "Kategori silindi",
    "ledger.create": "Kasa hareketi eklendi",
    "ledger.update": "Kasa hareketi güncellendi",
    "ledger.delete": "Kasa hareketi silindi",
    "announcement.create": "Duyuru yayınlandı",
    "announcement.update": "Duyuru güncellendi",
    "announcement.delete": "Duyuru silindi",
    "ticket.create": "Talep açıldı",
    "ticket.update": "Talep güncellendi",
  };
  return {
    html:
      heading(
        "İşlem geçmişi",
        "Son 200 yönetim işlemi ve mali değişiklik kaydı.",
      ) +
      `<section class="panel">${table(
        ["Tarih", "Kullanıcı", "İşlem", "Kayıt", "Ayrıntı"],
        rows.map((r) => [
          e(new Date(r.created_at).toLocaleString("tr-TR")),
          e(r.full_name),
          e(actionNames[r.action] || r.action),
          e(r.entity_id || "—"),
          e(JSON.stringify(r.detail) === "{}" ? "—" : JSON.stringify(r.detail)),
        ]),
      )}</section>`,
  };
};

// Formlar ortak bir erişilebilir dialog içinde açılır. API doğrulaması her zaman son otoritedir.
function field(label, name, value = "", type = "text", extra = "") {
  return `<label>${e(label)}<input name="${name}" type="${type}" value="${e(value)}" ${extra}></label>`;
}
function area(label, name, value = "", max = 10000) {
  return `<label class="wide">${e(label)}<textarea name="${name}" maxlength="${max}" required>${e(value)}</textarea></label>`;
}
function selectField(label, name, items, value = "", extra = "") {
  return `<label>${e(label)}<select name="${name}" ${extra}>${items.map(([v, l]) => `<option value="${e(v)}" ${String(v) === String(value) ? "selected" : ""}>${e(l)}</option>`).join("")}</select></label>`;
}
function checkbox(label, name, checked = false) {
  return `<label class="checkbox"><input name="${name}" type="checkbox" ${checked ? "checked" : ""}>${e(label)}</label>`;
}
function apartmentSelect(value) {
  return selectField(
    "Daire",
    "apartment_id",
    [
      ["", "Daire seçin"],
      ...state.apartments.map((a) => [
        a.id,
        `${a.block} Blok / ${a.number}${a.active ? "" : " (Pasif)"}`,
      ]),
    ],
    value,
    "required",
  );
}
let modalSave = null;
let modalBusy = false;
let returnFocus = null;
function openModal(title, html, wide = false) {
  const modal = $("#modal");
  returnFocus = document.activeElement;
  $("#modal-title").textContent = title;
  $("#modal-body").innerHTML = html;
  modal.classList.toggle("wide-modal", wide);
  modalSave = null;
  if (!modal.open) modal.showModal();
}
function closeModal() {
  if (modalBusy) return;
  const modal = $("#modal");
  if (modal?.open) {
    modal.close();
    returnFocus?.focus?.();
  }
  modalSave = null;
}
function formModal(title, fields, save, hint = "", submitLabel = "Kaydet") {
  openModal(
    title,
    `${hint ? `<p class="form-hint">${e(hint)}</p>` : ""}<form id="modal-form"><div class="form-grid">${fields}</div><p class="form-error" role="alert"></p><div class="form-actions"><button type="button" class="button" data-action="close-modal">Vazgeç</button><button type="submit" class="button primary">${e(submitLabel)}</button></div></form>`,
  );
  modalSave = save;
}
async function editForm(entity, id = null) {
  const row = id ? state.rows.find((r) => r.id === id) : null;
  const r = row || {};
  if (["resident", "payment"].includes(entity) || entity === "batch")
    state.apartments = await api("/apartments");
  if (entity === "ledger") state.categories = await api("/categories");
  const save = async (path, data, method = id ? "PUT" : "POST") => {
    const result = await api(path, { method, body: data });
    toast(result.message || "Kayıt başarıyla kaydedildi.");
    return result;
  };
  if (["payment", "ledger", "announcement"].includes(entity))
    return operationForm(entity, r, id, save);
  if (entity === "apartment") {
    formModal(
      id ? "Daireyi düzenle" : "Yeni daire",
      field("Blok", "block", r.block, "text", 'required maxlength="30"') +
        field(
          "Daire no",
          "number",
          r.number,
          "text",
          'required maxlength="20"',
        ) +
        field(
          "Kat",
          "floor",
          r.floor ?? 0,
          "number",
          'required min="-10" max="200" step="1"',
        ) +
        field(
          "Alan (m²)",
          "area",
          r.area,
          "number",
          'required min="0.01" step="0.01"',
        ) +
        field(
          "Arsa payı",
          "land_share",
          r.land_share,
          "number",
          'required min="0.0001" step="0.0001"',
        ) +
        checkbox("Aktif daire", "active", r.active ?? true),
      (data) =>
        save("/apartments" + (id ? "/" + id : ""), {
          ...data,
          active: data.active === "on",
        }),
      "Pasif daireler yeni toplu aidatlara dahil edilmez. Geçmiş mali kayıtları olan daireleri silmek yerine pasife alabilirsiniz.",
    );
  } else if (entity === "resident") {
    formModal(
      id ? "Sakini düzenle" : "Yeni sakin",
      field(
        "Ad soyad",
        "full_name",
        r.full_name,
        "text",
        'required maxlength="120"',
      ) +
        apartmentSelect(r.apartment_id) +
        field(
          "E-posta / giriş hesabı",
          "email",
          r.email,
          "email",
          'required maxlength="254"',
        ) +
        field(
          "İletişim telefonu (isteğe bağlı)",
          "phone",
          r.phone,
          "tel",
          'maxlength="30"',
        ) +
        selectField(
          "Oturum türü",
          "occupancy",
          [
            ["owner", "Ev sahibi"],
            ["tenant", "Kiracı"],
          ],
          r.occupancy,
        ) +
        field(
          "Giriş tarihi",
          "move_in",
          r.move_in || today(),
          "date",
          "required",
        ) +
        field(
          "Çıkış tarihi (isteğe bağlı)",
          "move_out",
          r.move_out || "",
          "date",
        ) +
        (id
          ? checkbox("Hesap aktif", "active", r.active)
          : field(
              "Kayıtlı hesabı yoksa geçici şifre",
              "password",
              "",
              "password",
              'minlength="12" autocomplete="new-password"',
            )),
      (data) =>
        save("/residents" + (id ? "/" + id : ""), {
          ...data,
          active: data.active === "on",
        }),
      "Sakinin e-posta adresini ve dairesini girin, geçici şifre belirleyin. Sakin ilk girişte kendi şifresini oluşturur.",
    );
  } else if (entity === "reset") {
    formModal(
      "Sakin şifresini sıfırla",
      field(
        "Yeni geçici şifre",
        "password",
        "",
        "password",
        'required minlength="12" autocomplete="new-password"',
      ),
      (data) => save(`/residents/${id}/password`, data, "POST"),
      "Şifreyi sakine güvenli bir yolla iletin. Mevcut oturumları kapanır ve ilk girişte şifresini değiştirmesi gerekir.",
    );
  } else if (entity === "batch") {
    formModal(
      "Toplu aidat oluştur",
      field("Aidat dönemi", "period", monthNow(), "month", "required") +
        field(
          "Son ödeme tarihi",
          "due_date",
          monthNow() + "-10",
          "date",
          "required",
        ) +
        field(
          "Daire başına tutar (₺)",
          "amount",
          "",
          "number",
          'required min="0.01" step="0.01"',
        ) +
        field(
          "Açıklama",
          "description",
          "Aylık ortak gider aidatı",
          "text",
          'required maxlength="250"',
        ),
      (data) => save("/charges/batch", data),
      "Tüm aktif dairelere eşit tutarda aidat tanımlanır. Seçilen dönemde zaten aidatı olan dairelere tekrar kayıt açılmaz.",
    );
  } else if (entity === "charge") {
    formModal(
      "Aidatı düzenle",
      field(
        "Tutar (₺)",
        "amount",
        r.amount,
        "number",
        'required min="0.01" step="0.01"',
      ) +
        field("Son ödeme tarihi", "due_date", r.due_date, "date", "required") +
        field(
          "Açıklama",
          "description",
          r.description,
          "text",
          'required maxlength="250"',
        ),
      (data) => save("/charges/" + id, data),
      "Daire bakiyesi ve ödemelerin mahsup dağılımı otomatik yeniden hesaplanır.",
    );
  } else if (entity === "ticket") {
    if (id) {
      formModal(
        "Talebi yönet",
        selectField("Durum", "status", Object.entries(statusNames), r.status) +
          `<div></div><label class="wide">Yönetimin yanıtı<textarea name="response" maxlength="10000">${e(r.response)}</textarea></label>`,
        (data) => save("/tickets/" + id, data),
        r.title + " — " + r.description,
      );
    } else {
      formModal(
        "Yeni arıza / talep",
        field("Başlık", "title", "", "text", 'required maxlength="180"') +
          selectField(
            "Öncelik",
            "priority",
            Object.entries(priorityNames),
            "normal",
          ) +
          area("Açıklama", "description"),
        (data) => save("/tickets", data),
        "Talebinizi mümkün olduğunca açık yazın. Durum ve yönetim yanıtını bu ekrandan takip edebilirsiniz.",
      );
    }
  } else if (entity === "category") {
    const category = id ? state.categories.find((c) => c.id === id) : {};
    formModal(
      id ? "Kategoriyi düzenle" : "Yeni kategori",
      field(
        "Kategori adı",
        "name",
        category?.name,
        "text",
        'required maxlength="100"',
      ) +
        (id
          ? ""
          : selectField(
              "Tür",
              "kind",
              [
                ["expense", "Gider"],
                ["income", "Gelir"],
              ],
              "expense",
            )),
      async (data) => {
        await save("/categories" + (id ? "/" + id : ""), data);
      },
      "Mevcut kategorinin türü değiştirilemez. Hareket kaydı bulunan kategori silinemez.",
    );
  }
}

async function confirmDelete(entity, id) {
  const paths = {
    apartment: "apartments",
    resident: "residents",
    charge: "charges",
    ledger: "ledger",
    announcement: "announcements",
    category: "categories",
  };
  const notes = {
    apartment:
      "Bu daireyi silmek istiyor musunuz? İlişkili mali veya sakin kaydı varsa işlem reddedilir. Bunun yerine daireyi pasife alabilirsiniz.",
    resident:
      "Sakin bilgileri silinecek ve giriş hesabı kapatılacak. Talep geçmişi isimsiz olarak korunacak. Devam edilsin mi?",
    charge:
      "Aidat silinecek ve bakiye yeniden hesaplanacak. Mevcut ödemeler daire hesabında kalacak.",
    ledger:
      "Bu kasa hareketi silinecek ve kasa bakiyesi değişecek. İşlem geçmişi korunur.",
    announcement: "Bu duyuru tüm sakinlerin panosundan kaldırılacak.",
    category: "Kategori silinsin mi? Kullanılmış kategoriler silinemez.",
  };
  if (!paths[entity]) return;
  formModal(
    "Silme işlemini onaylayın",
    "",
    async () => {
      await api(`/${paths[entity]}/${id}`, { method: "DELETE" });
      toast("Kayıt silindi.");
    },
    notes[entity],
    "Evet, sil",
  );
}
async function showStatement(id) {
  if (!id) {
    toast("Hesabınıza bağlı bir daire bulunmuyor.", true);
    return;
  }
  const data = await api(`/apartments/${id}/statement`),
    a = data.apartment;
  openModal(
    `${a.block} Blok · ${a.number} / Hesap ekstresi`,
    `<div class="summary-line"><div>Daire<strong>${e(a.block)} / ${e(a.number)}</strong></div><div>Toplam aidat<strong>${e(money(a.charged))}</strong></div><div>Toplam ödeme<strong>${e(money(a.paid))}</strong></div><div>${Number(a.balance) < 0 ? "Alacak" : "Borç"}<strong>${e(money(Math.abs(Number(a.balance))))}</strong></div></div>` +
      table(
        ["Tarih", "Açıklama", "Borç", "Ödeme", "Bakiye", "Makbuz"],
        data.rows.map((r) => [
          e(dateText(r.date)),
          e(r.description),
          moneyCell(r.debit),
          moneyCell(r.credit),
          moneyCell(r.balance),
          e(r.receipt_no) || "—",
        ]),
      ) +
      `<div class="form-actions">${button("CSV indir", "statement-csv", `data-id="${id}"`, "", "download")}${button("Yazdır", "print", "", "primary", "receipt")}</div>`,
    true,
  );
}
async function showReceipt(id) {
  const r = await api(`/payments/${id}/receipt`);
  openModal(
    "Tahsilat makbuzu",
    `<div class="receipt-head"><div class="brand"><span class="brand-mark">a.</span><span>avlu</span></div><div><strong>TAHSİLAT MAKBUZU</strong><p class="muted">${e(r.receipt_no)}</p></div></div>${r.voided_at ? `<div class="info-strip debt">İPTAL EDİLDİ · ${e(dateText(r.voided_at))}<br>${e(r.void_reason)}</div>` : ""}<div class="receipt-detail"><div><small>Daire</small><strong>${e(r.block)} Blok / ${e(r.number)}</strong></div><div><small>Ödeme tarihi</small>${e(dateText(r.paid_on))}</div><div><small>Ödeme yöntemi</small>${e(methodNames[r.method])}</div><div><small>Tahsil eden</small>${e(r.received_by)}</div></div><div class="receipt-amount">${e(money(r.amount))}</div><p class="form-hint">${e(r.note) || "Aidat ödemesi"}</p><div class="receipt-sign"><span>Ödeyen imzası: __________________</span><span>Yönetim imzası: __________________</span></div><p class="form-hint">Bu belge site içi tahsilat kaydıdır.</p><div class="form-actions">${button("Makbuzu yazdır", "print", "", "primary", "receipt")}</div>`,
  );
}
async function showCategories() {
  state.categories = await api("/categories");
  openModal(
    "Gelir / gider kategorileri",
    `<div class="toolbar">${button("Kategori ekle", "new", 'data-entity="category"')}</div>${table(
      ["Kategori", "Tür", "İşlemler"],
      state.categories.map((r) => [
        e(r.name),
        badge(
          r.kind === "income" ? "Gelir" : "Gider",
          r.kind === "income" ? "green" : "red",
        ),
        `<div class="row-actions">${editButton("category", r.id)}${deleteButton("category", r.id)}</div>`,
      ]),
    )}`,
  );
}
document.addEventListener("submit", async (event) => {
  if (event.target.id !== "modal-form") return;
  event.preventDefault();
  if (modalBusy || !modalSave) return;
  const form = event.target,
    save = modalSave,
    data = Object.fromEntries(new FormData(form));
  modalBusy = true;
  form.querySelectorAll("button").forEach((b) => (b.disabled = true));
  $("#modal-close").disabled = true;
  $(".form-error", form).textContent = "";
  try {
    await save(data);
    modalBusy = false;
    closeModal();
    await renderRoute();
  } catch (error) {
    $(".form-error", form).textContent = error.message;
  } finally {
    modalBusy = false;
    form.querySelectorAll("button").forEach((b) => (b.disabled = false));
    $("#modal-close").disabled = false;
  }
});
document.addEventListener("click", async (event) => {
  const target = event.target.closest("[data-action]");
  if (!target) return;
  const action = target.dataset.action,
    id = Number(target.dataset.id),
    entity = target.dataset.entity;
  if (action === "report-filter") return;
  try {
    if (action === "account-edit") {
      const account = state.rows.find((r) => r.id === id);
      formModal(
        "Hesap yetkileri",
        field(
          "Ad soyad",
          "full_name",
          account.full_name,
          "text",
          'required maxlength="120"',
        ) +
          selectField(
            "Rol",
            "role",
            [["resident", "Daire sakini"]],
            account.role,
          ) +
          selectField(
            "Üyelik",
            "membership_status",
            [
              ["pending", "Onay bekliyor"],
              ["approved", "Onaylı"],
            ],
            account.membership_status,
          ) +
          checkbox("Hesap aktif", "active", account.active),
        async (data) => {
          const result = await api("/accounts/" + id, {
            method: "PUT",
            body: { ...data, active: data.active === "on" },
          });
          toast(result.message);
        },
        account.email,
      );
    } else if (action === "account-password") {
      formModal(
        "Geçici şifre belirle",
        field(
          "Geçici şifre",
          "password",
          "",
          "password",
          'required minlength="12" autocomplete="new-password"',
        ),
        async (data) => {
          const result = await api(`/accounts/${id}/password`, {
            method: "POST",
            body: data,
          });
          toast(result.message);
        },
        "Şifreyi hesap sahibine güvenli bir yolla iletin. Kullanıcı ilk girişte şifresini değiştirir.",
      );
    } else if (action === "account-link") {
      const account = state.rows.find((r) => r.id === id);
      await editForm("resident");
      $('#modal-form [name="full_name"]').value = account.full_name;
      $('#modal-form [name="email"]').value = account.email;
    } else if (action === "new") await editForm(entity);
    else if (action === "edit") await editForm(entity, id);
    else if (action === "delete") await confirmDelete(entity, id);
    else if (action === "refresh") await renderRoute();
    else if (action === "refresh-membership") {
      state.user = await api("/auth/me");
      showApp();
    } else if (action === "close-modal") closeModal();
    else if (action === "statement") await showStatement(id);
    else if (action === "receipt") await showReceipt(id);
    else if (action === "print") window.print();
    else if (action === "categories") await showCategories();
    else if (action === "void")
      formModal(
        "Tahsilatı iptal et",
        area("İptal gerekçesi", "reason", "", 500),
        async (data) => {
          await api(`/payments/${id}/void`, { method: "POST", body: data });
          toast("Tahsilat iptal edildi.");
        },
        "İptal edilen tahsilat kasa ve daire hesabından düşülür; makbuz geçmişi korunur.",
        "Tahsilatı iptal et",
      );
    else if (action === "download-financial")
      await download("/reports/financial.csv?" + reportQuery());
    else if (action === "download-debtors")
      await download(
        "/reports/debtors.csv?overdue=" + $("#only-overdue").checked,
      );
    else if (action === "statement-csv")
      await download(`/apartments/${id}/statement.csv`);
    else if (action === "clear-charges") {
      $("#charge-month").value = "";
      $("#charge-status").value = "";
      $("#charge-status").dispatchEvent(new Event("change"));
    } else if (action === "clear-ledger") {
      $("#ledger-month").value = "";
      $("#ledger-kind").value = "";
      $("#ledger-kind").dispatchEvent(new Event("change"));
    }
  } catch (error) {
    toast(error.message, true);
  }
});
$("#modal-close").onclick = closeModal;
$("#modal").addEventListener("cancel", (event) => {
  if (modalBusy) event.preventDefault();
});
$("#menu-toggle").onclick = () =>
  setMenu(!$("#sidebar").classList.contains("open"));
$("#sidebar-backdrop").onclick = () => setMenu(false);
$("#profile-button").onclick = () => {
  location.hash = "settings";
};
$("#logout-button").onclick = async () => {
  try {
    await api("/auth/logout", { method: "POST" });
    showLogin();
    state.csrf = (await api("/auth/csrf")).csrf_token;
  } catch (error) {
    toast(error.message, true);
  }
};
$("#login-form").onsubmit = async (event) => {
  event.preventDefault();
  const form = event.target,
    b = $("button", form);
  b.disabled = true;
  $("#login-error").textContent = "";
  try {
    state.csrf = (await api("/auth/csrf")).csrf_token;
    const data = await api("/auth/login", {
      method: "POST",
      body: Object.fromEntries(new FormData(form)),
    });
    state.csrf = data.csrf_token;
    state.user = await api("/auth/me");
    form.reset();
    showApp();
  } catch (error) {
    $("#login-error").textContent = error.message;
  } finally {
    b.disabled = false;
  }
};
$("#register-form").onsubmit = async (event) => {
  event.preventDefault();
  const form = event.target,
    data = Object.fromEntries(new FormData(form)),
    submit = $("button", form);
  $("#register-error").textContent = "";
  if (data.password !== data.confirm_password) {
    $("#register-error").textContent = "Şifreler eşleşmiyor.";
    return;
  }
  if (new TextEncoder().encode(data.password).length > 72) {
    $("#register-error").textContent = "Şifre en fazla 72 UTF-8 bayt olabilir.";
    return;
  }
  submit.disabled = true;
  try {
    state.csrf = (await api("/auth/csrf")).csrf_token;
    const result = await api("/auth/register", {
      method: "POST",
      body: {
        email: data.email,
        password: data.password,
        full_name: data.full_name,
        site_name: data.site_name,
      },
    });
    form.reset();
    $('#login-form [name="email"]').value = data.email;
    location.hash = "login";
    showLogin();
    toast(result.message);
  } catch (error) {
    $("#register-error").textContent = error.message;
  } finally {
    submit.disabled = false;
  }
};
window.addEventListener("hashchange", () =>
  state.user ? renderRoute() : showLogin(),
);
(async () => {
  try {
    state.csrf = (await api("/auth/csrf")).csrf_token;
    state.user = await api("/auth/me");
    showApp();
  } catch (error) {
    showLogin();
    if (error.status !== 401) $("#login-error").textContent = error.message;
  }
})();
