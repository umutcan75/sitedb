"""İlk süper admin hesabını terminalden, gerçek kullanıcı bilgileriyle oluşturur."""
import getpass
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.app import create_app
from backend.db import transaction
from backend.identity import hash_password
from backend.validation import email, password, text
from backend.security import audit


def main():
    data = {'full_name': input('Ad soyad: ').strip(), 'email': input('E-posta: ').strip(),
            'password': getpass.getpass('Şifre: ')}
    if data['password'] != getpass.getpass('Şifre tekrar: '):
        raise SystemExit('Şifreler eşleşmiyor.')
    address, supplied, name = email(data), password(data), text(data, 'full_name', 120)
    app = create_app()
    try:
        with app.app_context(), transaction() as cur:
            cur.execute('SELECT pg_advisory_xact_lock(817220603)')
            cur.execute("SELECT id FROM users WHERE role='super_admin' AND active AND membership_status='approved'")
            if cur.fetchone():
                raise SystemExit('Aktif süper admin mevcut. Site yöneticilerini süper admin panelinden ekleyin.')
            cur.execute('''INSERT INTO users(full_name,email,password_hash,role,membership_status,must_change_password)
                VALUES(%s,%s,%s,'super_admin','approved',FALSE) RETURNING id''', (name,address,hash_password(supplied)))
            user_id = cur.fetchone()['id']
            audit(cur, 'account.bootstrap', user_id)
        print('Süper admin hesabı oluşturuldu.')
    finally:
        app.extensions['database'].close()


if __name__ == '__main__':
    main()
