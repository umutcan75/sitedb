"""Sunucuda kurulum ve yedekleme hesabını configparser biçiminde kaydeder."""
import argparse
import configparser
import getpass
import io
from pathlib import Path
from configure_production import write_private


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    config = configparser.ConfigParser(interpolation=None)
    name = input('Veritabanı adı: ').strip()
    user = input('Kurulum PostgreSQL kullanıcısı: ').strip()
    password = getpass.getpass('Kurulum PostgreSQL şifresi: ')
    if not name or not user or not password or any(c in name + user + password for c in '\r\n\x00'):
        raise SystemExit('Geçerli veritabanı adı, kullanıcı ve şifre gerekli.')
    config['DATABASE'] = dict(path='/var/lib/sitedb', host='127.0.0.1', port='5432',
                              dbname=name, user=user, password=password)
    stream = io.StringIO()
    config.write(stream)
    write_private(args.output, stream.getvalue())
    print('Kurulum yapılandırması kaydedildi; mevcut dosyanın üzerine yazılmaz.')
