"""PostgreSQL yedeği alır; şifreyi komut satırına veya çıktıya yazmaz."""
import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.config import load_config


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--pg-dump', default='pg_dump')
    args = parser.parse_args()
    executable = shutil.which(args.pg_dump)
    if not executable:
        raise SystemExit('pg_dump bulunamadı. PostgreSQL bin dizinini PATH içine ekleyin veya --pg-dump ile tam yol verin.')
    db = load_config(args.config)['DATABASE']
    args.output.mkdir(parents=True, exist_ok=True)
    name = datetime.now(timezone.utc).strftime('sitedb-%Y%m%dT%H%M%S%fZ.dump')
    destination = args.output / name
    with TemporaryDirectory(prefix='sitedb_backup_') as folder:
        pgpass = Path(folder) / 'pgpass'
        escape = lambda value: value.replace('\\', '\\\\').replace(':', '\\:')
        with os.fdopen(os.open(pgpass, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'w', encoding='utf-8') as stream:
            stream.write(':'.join(escape(db[k]) for k in ('host','port','dbname','user','password')) + '\n')
        env = {**os.environ, 'PGPASSFILE': str(pgpass)}
        env.pop('PGPASSWORD', None)
        fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, 'wb') as stream:
                subprocess.run([executable, '-h', db['host'], '-p', db['port'], '-U', db['user'],
                                '-d', db['dbname'], '-Fc', '--no-password'], env=env, stdout=stream, check=True)
        except Exception:
            destination.unlink(missing_ok=True)
            raise
    print(f'Yedek oluşturuldu: {destination}')


if __name__ == '__main__':
    main()
