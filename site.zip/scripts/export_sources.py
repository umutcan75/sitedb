"""Kod dökümü ve dağıtım paketini yerel sırları dahil etmeden üretir."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]


def main():
    files = []
    for directory in ('backend', 'database', 'frontend', 'scripts', 'tests', 'docs', 'deploy'):
        files.extend(path for path in (ROOT / directory).rglob('*')
                     if path.is_file() and path.suffix in ('.py', '.sql', '.html', '.css', '.js', '.md', '.service', '.timer')
                     and '__pycache__' not in path.parts and 'private' not in path.parts)
    files.extend(ROOT / name for name in ('requirements.txt', 'requirements-lock.txt', 'init_db.py',
                                         'run.py', 'start.bat', 'pytest.ini', '.gitignore', 'README.md'))
    readme = (ROOT / 'README.md').read_text(encoding='utf-8')
    contents = [readme[:readme.index('# Çalıştırma')], '# Dosya dosya kaynak kodları\n']
    languages = {'.py':'python', '.sql':'sql', '.html':'html', '.css':'css', '.js':'javascript', '.ini':'ini', '.bat':'bat'}
    for path in sorted(set(files)):
        relative = path.relative_to(ROOT).as_posix()
        code = path.read_text(encoding='utf-8-sig').rstrip()
        contents.append(f'\n## {relative}\n\n````{languages.get(path.suffix, "text")}\n{code}\n````\n')
    document = ROOT / 'KAYNAK_KODLAR.md'
    document.write_text('\n'.join(contents), encoding='utf-8')
    files.append(document)
    archive = ROOT / 'sitedb-kaynak-kod.zip'
    with ZipFile(archive, 'w', ZIP_DEFLATED) as package:
        for path in sorted(set(files)):
            package.write(path, 'sitedb/' + path.relative_to(ROOT).as_posix())
    with ZipFile(archive) as package:
        if package.testzip() is not None:
            raise RuntimeError('Kaynak paketi doğrulanamadı.')
    print(f'{len(set(files))} dosya paketlendi: {archive}')


if __name__ == '__main__':
    main()
