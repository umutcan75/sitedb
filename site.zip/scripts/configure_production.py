"""Gerçek alan adı ve yerel gizli girişle canlı config.ini ve Caddyfile üretir."""
import argparse
import configparser
import getpass
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.config import valid_domain, production_settings


def write_private(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8', newline='\n') as stream:
        stream.write(content)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--state-path', default='/var/lib/sitedb')
    args = parser.parse_args()
    if (args.output / 'config.ini').exists() or (args.output / 'Caddyfile').exists():
        raise SystemExit('Hedefte yapılandırma var; üzerine yazılmaz. Yeni bir çıktı dizini seçin.')
    domain = input('Uygulamanın tam alan adı (https:// olmadan): ').strip().lower().encode('idna').decode('ascii')
    if not valid_domain(domain):
        raise SystemExit('Geçerli alan adı girin.')
    dbname = input('PostgreSQL veritabanı adı: ').strip()
    password = getpass.getpass('sitedb_service veritabanı şifresi: ')
    if not dbname or len(password) < 24 or any(c in password + dbname for c in '\r\n\x00'):
        raise SystemExit('Veritabanı adı gerekli; şifre en az 24 karakter olmalı, satır sonu içermemeli.')
    config = configparser.ConfigParser(interpolation=None)
    config['DATABASE'] = dict(path=args.state_path, host='127.0.0.1', port='5432',
                              dbname=dbname, user='sitedb_service', password=password)
    config['APP'] = dict(environment='production', host='127.0.0.1', port='5000',
                         cookie_secure='true', trusted_hosts=domain, trusted_proxy='127.0.0.1',
                         allowed_origins='', pool_min='1', pool_max='12')
    production_settings(config)
    import io
    stream = io.StringIO()
    config.write(stream)
    write_private(args.output / 'config.ini', stream.getvalue())
    write_private(args.output / 'Caddyfile', f'''# Alan adı üzerinden otomatik HTTPS ve sertifika yenileme.
{domain} {{
    encode zstd gzip
    request_body {{
        max_size 6MB
    }}
    reverse_proxy 127.0.0.1:5000
    header -Server
}}
''')
    print('Yayın yapılandırması oluşturuldu. Şifreler ekrana yazdırılmadı.')


if __name__ == '__main__':
    main()
