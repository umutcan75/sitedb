"""Kurulum hesabıyla sınırlı PostgreSQL servis hesabı oluşturur veya yetkilerini yeniler."""
import argparse
import getpass
import re
import sys
from pathlib import Path
import psycopg2
from psycopg2 import sql

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.config import load_config, db_params


def provision(config, username, password):
    if not re.fullmatch(r'sitedb_service(?:_[a-z0-9]+)?', username):
        raise ValueError('Servis hesabı adı sitedb_service veya sitedb_service_ ile başlayan bir ad olmalıdır.')
    if len(password) < 24:
        raise ValueError('Veritabanı servis şifresi en az 24 karakter olmalıdır.')
    role = sql.Identifier(username)
    conn = psycopg2.connect(**db_params(config))
    try:
        with conn, conn.cursor() as cur:
            cur.execute('SELECT 1 FROM pg_roles WHERE rolname=%s', (username,))
            if not cur.fetchone():
                cur.execute(sql.SQL('CREATE ROLE {}').format(role))
            cur.execute(sql.SQL('ALTER ROLE {} LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOINHERIT PASSWORD %s').format(role), (password,))
            cur.execute(sql.SQL('GRANT CONNECT ON DATABASE {} TO {}').format(sql.Identifier(config['DATABASE']['dbname']), role))
            cur.execute(sql.SQL('GRANT sitedb_runtime TO {}').format(role))
            # --no-privileges ile taşınmış yedeklerde site rolünün izinlerini de kurar.
            cur.execute('GRANT USAGE ON SCHEMA sitedb TO sitedb_runtime')
            cur.execute('GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA sitedb TO sitedb_runtime')
            cur.execute('GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA sitedb TO sitedb_runtime')
            cur.execute('REVOKE INSERT,UPDATE,DELETE ON sitedb.sites,sitedb.schema_migrations FROM sitedb_runtime')
            cur.execute('REVOKE UPDATE,DELETE ON sitedb.audit_log FROM sitedb_runtime')
            cur.execute(sql.SQL('GRANT USAGE ON SCHEMA sitedb TO {}').format(role))
            cur.execute(sql.SQL('GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA sitedb TO {}').format(role))
            cur.execute(sql.SQL('GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA sitedb TO {}').format(role))
            cur.execute(sql.SQL('REVOKE INSERT,UPDATE,DELETE ON sitedb.schema_migrations FROM {}').format(role))
            cur.execute(sql.SQL('REVOKE UPDATE,DELETE ON sitedb.audit_log FROM {}').format(role))
            # Platform ve giriş sorguları globaldir; site işlemleri transaction başında
            # ayrı sitedb_runtime rolüne düşer. Runtime rolü bu politikayı devralmaz.
            cur.execute("SELECT tablename FROM pg_tables WHERE schemaname='sitedb' AND rowsecurity")
            for (table,) in cur.fetchall():
                target = sql.Identifier('sitedb', table)
                policy = sql.Identifier('service_' + username)
                cur.execute(sql.SQL('DROP POLICY IF EXISTS {} ON {}').format(policy, target))
                cur.execute(sql.SQL('CREATE POLICY {} ON {} TO {} USING(TRUE) WITH CHECK(TRUE)').format(policy, target, role))
    finally:
        conn.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--user', default='sitedb_service')
    args = parser.parse_args()
    password = getpass.getpass('Yeni/yenilenecek servis şifresi (en az 24 karakter): ')
    if password != getpass.getpass('Servis şifresi tekrar: '):
        raise SystemExit('Şifreler eşleşmiyor.')
    provision(load_config(args.config), args.user, password)
    print('Servis hesabı ve yetkileri hazır. Aynı şifreyi yayın yapılandırmasına girin.')
