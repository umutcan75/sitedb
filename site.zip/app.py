"""Windows üzerinde Waitress ile çalıştırma; debug modu kullanılmaz."""
from waitress import serve
from backend.app import create_app
from backend.config import load_config, production_settings


def server_options(config):
    production_settings(config)
    options = dict(host=config.get('APP', 'host', fallback='127.0.0.1'),
                   port=config.getint('APP', 'port', fallback=5000), threads=8,
                   max_request_body_size=6*1024*1024, channel_timeout=60,
                   clear_untrusted_proxy_headers=True, expose_tracebacks=False)
    proxy = config.get('APP', 'trusted_proxy', fallback='').strip()
    if proxy:
        if proxy != '127.0.0.1':
            raise RuntimeError('Bu kurulum yalnızca yerel 127.0.0.1 proxy adresini destekler.')
        options.update(trusted_proxy=proxy, trusted_proxy_count=1,
                       trusted_proxy_headers={'x-forwarded-for', 'x-forwarded-proto'})
    return options

if __name__ == '__main__':
    config = load_config()
    options = server_options(config)
    host, port = options['host'], options['port']
    print(f'Site Yönetimi: http://{host}:{port}', flush=True)
    serve(create_app(), **options)
